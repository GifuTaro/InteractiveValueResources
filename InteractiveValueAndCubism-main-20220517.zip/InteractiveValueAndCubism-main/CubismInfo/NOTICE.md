## [注意事項] Cubism 4 SDK for Web R1 以降へのアップデートに伴う注意

Cubism 4 SDK for Web R1 にてそれ以前のベータ版から正式版のリリースに伴い、
利便性向上のためパッケージ及びリポジトリの構造変更がおこなわれました。

この変更は Cubism 4 SDK for Native と構造を変えずに運用がなされるほか、
ユーザに管理が不必要なファイルが混在することを避けることが理由です。

構造の変更点、及び Cubism 4 SDK for Web beta2 以前のプロジェクトからの更新方法に関して、
[Cubism SDK Manual] に詳細を記載しています。アップデートを行う際は必ずご確認ください。

[Cubism SDK Manual]: https://docs.live2d.com/cubism-sdk-manual/warning-for-cubism4-web-r1-update/
