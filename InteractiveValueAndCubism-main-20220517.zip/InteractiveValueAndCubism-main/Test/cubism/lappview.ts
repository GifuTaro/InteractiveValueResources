/**
 * Copyright(c) Live2D Inc. All rights reserved.
 *
 * Use of this source code is governed by the Live2D Open Software license
 * that can be found at https://www.live2d.com/eula/live2d-open-software-license-agreement_en.html.
 */

import { CubismMatrix44 } from "@framework/math/cubismmatrix44";
import { CubismViewMatrix } from "@framework/math/cubismviewmatrix";

import * as LAppDefine from "./lappdefine";
import { canvas, gl, LAppDelegate } from "./lappdelegate";
import { LAppLive2DManager } from "./lapplive2dmanager";
import { LAppPal } from "./lapppal";
import { LAppSprite } from "./lappsprite";
import { TextureInfo } from "./lapptexturemanager";
import { TouchManager } from "./touchmanager";

/**
 * 描画クラス。
 */
export class LAppView {
    _touchManager: TouchManager | null; // タッチマネージャー
    _deviceToScreen: CubismMatrix44 | null; // デバイスからスクリーンへの行列
    _viewMatrix: CubismViewMatrix | null; // viewMatrix
    _programId: WebGLProgram | null; // シェーダID
    _back: LAppSprite | null; // 背景画像
    _gear: LAppSprite | null; // ギア画像
    _logo: LAppSprite | null; //ロゴ画像---------------------------
    _changeModel: boolean; // モデル切り替えフラグ
    _isClick: boolean; // クリック中
    /**
     * コンストラクタ
     */
    constructor() {
        this._programId = null;
        this._back = null;
        this._gear = null;
        this._logo = null;

        // タッチ関係のイベント管理ー－－－－－－－－－－－－－－－－－－－－タッチイベント管理
        this._touchManager = new TouchManager();

        // デバイス座標からスクリーン座標に変換するための　https://docs.live2d.com/cubism-sdk-manual/layout/
        this._deviceToScreen = new CubismMatrix44(); //CubismMatrix44のインスタンスモデルの大きさ位置

        // 画面の表示の拡大縮小や移動の変換を行う行列
        this._viewMatrix = new CubismViewMatrix();

        this._changeModel = false;
        this._isClick = false;
    }

    /**
     * 初期化する。
     */
    public initialize(): void {
        const { width, height } = canvas as HTMLCanvasElement;

        const ratio: number = width / height;
        const left: number = -ratio;
        const right: number = ratio;
        const bottom: number = LAppDefine.ViewLogicalLeft;
        const top: number = LAppDefine.ViewLogicalRight;

        this._viewMatrix?.setScreenRect(left, right, bottom, top); // デバイスに対応する画面の範囲。 Xの左端、Xの右端、Yの下端、Yの上端
        this._viewMatrix?.scale(LAppDefine.ViewScale, LAppDefine.ViewScale);

        this._deviceToScreen?.loadIdentity(); //CubismMatrix44のインスタンスモデルの大きさ位置
        if (width > height) {
            const screenW: number = Math.abs(right - left);
            this._deviceToScreen?.scaleRelative(screenW / width, -screenW / width);
        } else {
            const screenH: number = Math.abs(top - bottom);
            this._deviceToScreen?.scaleRelative(screenH / height, -screenH / height);
        }
        this._deviceToScreen?.translateRelative(-width * 0.5, -height * 0.5);

        // 表示範囲の設定
        this._viewMatrix?.setMaxScale(LAppDefine.ViewMaxScale); // 限界拡張率
        this._viewMatrix?.setMinScale(LAppDefine.ViewMinScale); // 限界縮小率

        // 表示できる最大範囲
        this._viewMatrix?.setMaxScreenRect(LAppDefine.ViewLogicalMaxLeft, LAppDefine.ViewLogicalMaxRight, LAppDefine.ViewLogicalMaxBottom, LAppDefine.ViewLogicalMaxTop);
    }

    /**
     * 解放する
     */
    public release(): void {
        this._viewMatrix = null;
        this._touchManager = null;
        this._deviceToScreen = null;

        this._gear?.release();
        this._gear = null;

        this._logo?.release();
        this._logo = null;

        this._back?.release();
        this._back = null;

        gl?.deleteProgram(this._programId);
        this._programId = null;
    }

    /**
     * 背景と歯車のみ描画する。
     * まだLive2dモデルは描画していない
     * １．「lappdelegate」から呼ばれる
     */
    public render(): void {
        gl?.useProgram(this._programId);

        if (this._back) {
            this._back.render(this._programId as WebGLProgram);
        }

        if (this._gear) {
            this._gear.render(this._programId as WebGLProgram);
        }

        if (this._logo) {
            //---------------------------ロゴ
            this._logo.render(this._programId as WebGLProgram);
        }

        gl?.flush();

        const live2DManager: LAppLive2DManager = LAppLive2DManager.getInstance();

        live2DManager.setViewMatrix(this._viewMatrix as CubismMatrix44); //モデル空間をセットする

        live2DManager.onUpdate(); //-----------------------2.描画処理 モデルマネージャーを呼び出す
    }

    /**
     * 画像の初期化を行う。
     */
    public initializeSprite(): void {
        if (canvas) {
            const width: number = canvas.width; //キャンバスの大きさを取得
            const height: number = canvas.height;

            const textureManager = LAppDelegate.getInstance().getTextureManager();
            const resourcesPath = LAppDefine.ResourcesPath;

            let imageName = "";
            //--------------------------------------------画像追加の流れ

            // 背景画像初期化
            imageName = LAppDefine.BackImageName; //パスを取得

            // 非同期なのでコールバック関数を作成
            const initBackGroundTexture = (textureInfo: TextureInfo): void => {
                const x: number = width * 0.5;
                const y: number = height * 0.5;

                const fwidth = textureInfo.width * 2.0;
                const fheight = height * 1.0; //0.95
                this._back = new LAppSprite(x, y, fwidth, fheight, textureInfo.id);
            };

            //テクスチャマネージャーにコールバック関数を受け渡す
            textureManager.createTextureFromPngFile(resourcesPath + imageName, false, initBackGroundTexture);

            //------------------------------------------------

            /*
            // ロゴ画像初期化
            imageName = LAppDefine.LogoImageName;
            const initLogoTexture = (textureInfo: TextureInfo): void => {
                const x = textureInfo.width * 0.3;
                const y = textureInfo.height * 0.3;
                const fwidth = textureInfo.width;
                const fheight = textureInfo.height;
                this._logo = new LAppSprite(x, y, fwidth, fheight, textureInfo.id);
            };

            textureManager.createTextureFromPngFile(
                resourcesPath + imageName,
                false,
                initLogoTexture
            );
            */

            // 歯車画像初期化

            /*
            imageName = LAppDefine.GearImageName;
            const initGearTexture = (textureInfo: TextureInfo): void => {
                const x = width - textureInfo.width * 0.5;
                const y = height - textureInfo.height * 0.5;
                const fwidth = textureInfo.width;
                const fheight = textureInfo.height;
                this._gear = new LAppSprite(x, y, fwidth, fheight, textureInfo.id as WebGLTexture);
            };

            textureManager?.createTextureFromPngFile(resourcesPath + imageName, false, initGearTexture);
            */

            // シェーダーを作成
            if (this._programId == null) {
                this._programId = LAppDelegate.getInstance().createShader() as WebGLProgram | null;
            }
        }
    }

    /**
     * タッチされた時に呼ばれる。
     *
     * @param pointX スクリーンX座標
     * @param pointY スクリーンY座標
     */
    public onTouchesBegan(pointX: number, pointY: number): void {
        /**
         * スクリーン座標を管理するクラス
         * マウス座標を登録
         */
        this._touchManager?.touchesBegan(pointX, pointY);
    }

    /**
     * タッチしているときにポインタが動いたら呼ばれる。
     *
     * @param pointX スクリーンX座標
     * @param pointY スクリーンY座標
     */
    public onTouchesMoved(pointX: number, pointY: number): void {
        //論理座標をtouchManagerから取得
        const viewX: number = this.transformViewX(this._touchManager?.getX() as number) as number;
        const viewY: number = this.transformViewY(this._touchManager?.getY() as number) as number;

        //スクリーン座標を管理するクラス、マウス座標を更新
        this._touchManager?.touchesMoved(pointX, pointY);

        const live2DManager: LAppLive2DManager = LAppLive2DManager.getInstance();
        live2DManager.onDrag(viewX, viewY); //------------モデルマネージャーにマウス移動を伝えている＝dragManagerで顔の向きを求める
    }

    /**
     * タッチが終了したら呼ばれる。
     *
     * @param pointX スクリーンX座標
     * @param pointY スクリーンY座標
     */
    public onTouchesEnded(pointX: number, pointY: number): void {
        // タッチ終了
        const live2DManager: LAppLive2DManager = LAppLive2DManager.getInstance();
        live2DManager.onDrag(0.0, 0.0);

        {
            // シングルタップ
            const x: number = this._deviceToScreen?.transformX(this._touchManager?.getX() as number) as number; // 論理座標変換した座標を取得。
            const y: number = this._deviceToScreen?.transformY(this._touchManager?.getY() as number) as number; // 論理座標変化した座標を取得。

            if (LAppDefine.DebugTouchLogEnable) {
                LAppPal.printMessage(`[APP]touchesEnded x: ${x} y: ${y}`);
            }
            live2DManager.onTap(x, y); //------------モデルマネージャーにマウスが離れたことをt伝える

            /*
      // 歯車にタップしたかを判定している-----------------------------------------ここの歯車をオフにする
      if (this._gear.isHit(pointX, pointY)) {
        live2DManager.nextScene();
      }
      */
        }
    }
    /**
     * タッチが終了したら呼ばれる。
     *
     * @param pointX スクリーンX座標
     * @param pointY スクリーンY座標
     */
    public onFront(): void {
        // タッチ終了
        const live2DManager: LAppLive2DManager = LAppLive2DManager.getInstance();
        live2DManager.onDrag(0.0, 0.0);
    }

    /**
     * X座標をView座標に変換する。
     *
     * @param deviceX デバイスX座標
     */
    public transformViewX(deviceX: number): number | undefined {
        const screenX: number = this._deviceToScreen?.transformX(deviceX) as number; // 論理座標変換した座標を取得。
        return this._viewMatrix?.invertTransformX(screenX); // 拡大、縮小、移動後の値。
    }

    /**
     * Y座標をView座標に変換する。
     *
     * @param deviceY デバイスY座標
     */
    public transformViewY(deviceY: number): number | undefined {
        const screenY: number = this._deviceToScreen?.transformY(deviceY) as number; // 論理座標変換した座標を取得。
        return this._viewMatrix?.invertTransformY(screenY);
    }

    /**
     * X座標をScreen座標に変換する。
     * @param deviceX デバイスX座標
     */
    public transformScreenX(deviceX: number): number | undefined {
        return this._deviceToScreen?.transformX(deviceX);
    }

    /**
     * Y座標をScreen座標に変換する。
     *
     * @param deviceY デバイスY座標
     */
    public transformScreenY(deviceY: number): number | undefined {
        return this._deviceToScreen?.transformY(deviceY);
    }
}
