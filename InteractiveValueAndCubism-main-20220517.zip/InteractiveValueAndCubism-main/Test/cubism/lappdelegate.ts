/**
 * Copyright(c) Live2D Inc. All rights reserved.
 *
 * Use of this source code is governed by the Live2D Open Software license
 * that can be found at https://www.live2d.com/eula/live2d-open-software-license-agreement_en.html.
 */

import { CubismFramework, Option } from "@framework/live2dcubismframework";

import * as LAppDefine from "./lappdefine";
import { LAppLive2DManager } from "./lapplive2dmanager";
import { LAppPal } from "./lapppal";
import { LAppTextureManager } from "./lapptexturemanager";
import { LAppView } from "./lappview";

export let canvas: HTMLCanvasElement | null = null;
export let s_instance: LAppDelegate | null = null;
export let gl: WebGLRenderingContext | null = null;
export let frameBuffer: WebGLFramebuffer | null = null;

//-------------------------------------------------------------------------
/**
 * アプリケーションクラス。
 * Cubism SDKの管理を行う。
 */
export class LAppDelegate {
    /**
     * クラスのインスタンス（シングルトン）を返す。
     * インスタンスが生成されていない場合は内部でインスタンスを生成する。
     *
     * @return クラスのインスタンス
     */
    public static getInstance(): LAppDelegate {
        if (s_instance == null) {
            s_instance = new LAppDelegate();
        }

        return s_instance;
    }

    public static isRunning(): boolean {
        if (s_instance == null) {
            return false;
        } else {
            return s_instance._isRunning;
        }
    }

    /**
     * クラスのインスタンス（シングルトン）を解放する。
     */
    public static releaseInstance(): void {
        if (s_instance != null) {
            s_instance.release();
        }

        s_instance = null;
    }

    /**
     * APPに必要な物を初期化する。
     */
    public initialize(): boolean {
        if (LAppDefine.Placement === "produce") {
            //- キャンバスの作成//!ここをgetにすれば任意の位置に配置できる
            canvas = document.createElement("canvas");
            //ウィンドウサイズか固定サイズが
            if (LAppDefine.CanvasSize === "auto") {
                this._resizeCanvas();
            } else {
                canvas.width = LAppDefine.CanvasSize?.width as number;
                canvas.height = LAppDefine.CanvasSize?.height as number;
            }
            //-
        } else {
            canvas = document.getElementById("agent") as HTMLCanvasElement;
        }

        //-glコンテキストを初期化
        // @ts-ignore
        //キャンバスエレメントから、描画できるオブジェクトを取得
        gl = canvas.getContext("webgl") || canvas.getContext("experimental-webgl"); //??へ
        //-

        //-サポートしていない場合の警告
        if (!gl) {
            alert("Cannot initialize WebGL. This browser does not support.");
            gl = null;

            document.body.innerHTML = "This browser does not support the <code>&lt;canvas&gt;</code> element.";

            // gl初期化失敗
            return false;
        }
        //-

        if (LAppDefine.Placement === "produce") {
            if (LAppDefine.CanvasSize === "auto") {
                document.body.appendChild(canvas);
            } else {
                //-キャンバスを DOM に追加//!ここを変えれば任意の位置に追加できる
                const location = document.getElementById("agent");
                location?.appendChild(canvas);
            }
        }

        //const logo = document.getElementById("logo");
        //location.insertBefore(canvas,logo.nextSibling);

        //-バッファを取得
        if (!frameBuffer) {
            frameBuffer = gl.getParameter(gl.FRAMEBUFFER_BINDING);
        }

        // 透過設定
        gl.enable(gl.BLEND);
        gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);

        //canvasオブジェクトにontouchend()メソッドがあるかどうかをbooleanで返す
        const supportTouch: boolean = "ontouchend" in canvas;

        if (supportTouch) {
            // タッチ関連コールバック関数登録
            canvas.ontouchstart = onTouchBegan;
            canvas.ontouchmove = onTouchMoved;
            canvas.ontouchend = onTouchEnded;
            canvas.ontouchcancel = onTouchCancel;
        } else {
            // マウス関連コールバック関数登録
            canvas.onmousedown = onClickBegan; //マウスを押したときに呼ばれる
            canvas.onmousemove = onMouseMoved; //マウスを押し続けている間
            canvas.onmouseup = onClickEnded; //マウスを離したときよばれる
            canvas.onclick = onClick; //クリックされたとき

            canvas.onmouseout = onMouseRemoved; //カーソルががキャンバスから離れた時に呼ばれる
            canvas.onmouseover = onClickBegan; //カーソルがが侵入したら
            canvas.onmousemove = onMouseMoved; //カーソルが動いている間
        }

        // AppViewの初期化
        this._view?.initialize();

        // Cubism SDKの初期化
        this.initializeCubism();

        return true;
    }

    /**
     * Resize canvas and re-initialize view.
     */
    public onResize(): void {
        this._resizeCanvas();
        this._view?.initialize();
        this._view?.initializeSprite();
    }

    /**
     * 解放する。
     */
    public release(): void {
        clearInterval(this._intervalId as NodeJS.Timeout);
        this._textureManager?.release();
        this._textureManager = null;

        this._view?.release();
        this._view = null;

        // リソースを解放
        LAppLive2DManager.releaseInstance();

        // Cubism SDKの解放
        CubismFramework.dispose();
    }

    /**
     * 実行処理。
     */
    public run(): void {
        // メインループ
        const loop = (): void => {
            // インスタンスの有無の確認
            if (s_instance == null) {
                return;
            }

            // 時間更新　デルタタイムを取得
            LAppPal.updateTime();

            // 画面の初期化
            //gl.clearColor(0.0, 0.0, 0.0, 1.0);
            gl?.clearColor(0.0, 0.0, 0.0, 0.0);

            // 深度テストを有効化
            gl?.enable(gl.DEPTH_TEST);

            // 近くにある物体は、遠くにある物体を覆い隠す
            gl?.depthFunc(gl.LEQUAL);

            // カラーバッファや深度バッファをクリアする
            gl?.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

            gl?.clearDepth(1.0);

            // 透過設定
            gl?.enable(gl.BLEND);
            gl?.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);

            // 描画更新
            this._view?.render(); //-----------------------------------------1.描画処理

            // ループのために再帰呼び出し
            //requestAnimationFrame(loop);
        };
        //loop();
        const perTime: number = 1000 / LAppDefine.flameRate;
        this._intervalId = setInterval(loop, perTime); //----------------------------------------ここで非同期の再帰処理を行う
        this._isRunning = true;
    }

    /**
     * シェーダーを登録する。
     */
    public createShader(): WebGLProgram | null | undefined {
        // バーテックスシェーダーのコンパイル
        const vertexShaderId = gl?.createShader(gl.VERTEX_SHADER);

        if (vertexShaderId == null) {
            LAppPal.printMessage("failed to create vertexShader");
            return null;
        }

        const vertexShader: string = "precision mediump float;" + "attribute vec3 position;" + "attribute vec2 uv;" + "varying vec2 vuv;" + "void main(void)" + "{" + "   gl_Position = vec4(position, 1.0);" + "   vuv = uv;" + "}";

        gl?.shaderSource(vertexShaderId, vertexShader);
        gl?.compileShader(vertexShaderId);

        // フラグメントシェーダのコンパイル
        const fragmentShaderId = gl?.createShader(gl.FRAGMENT_SHADER);

        if (fragmentShaderId == null) {
            LAppPal.printMessage("failed to create fragmentShader");
            return null;
        }

        const fragmentShader: string = "precision mediump float;" + "varying vec2 vuv;" + "uniform sampler2D texture;" + "void main(void)" + "{" + "   gl_FragColor = texture2D(texture, vuv);" + "}";

        gl?.shaderSource(fragmentShaderId, fragmentShader);
        gl?.compileShader(fragmentShaderId);

        // プログラムオブジェクトの作成
        const programId = gl?.createProgram();
        gl?.attachShader(programId as WebGLProgram, vertexShaderId);
        gl?.attachShader(programId as WebGLProgram, fragmentShaderId);

        gl?.deleteShader(vertexShaderId);
        gl?.deleteShader(fragmentShaderId);

        // リンク
        gl?.linkProgram(programId as WebGLProgram);

        gl?.useProgram(programId as WebGLProgram);

        return programId;
    }

    /**
     * View情報を取得する。
     */
    public getView(): LAppView | null {
        return this._view;
    }

    public getTextureManager(): LAppTextureManager | null {
        return this._textureManager;
    }

    /**
     * Cubism SDKの初期化
     */
    public initializeCubism(): void {
        //-フレームワーク起動
        // setup cubism
        this._cubismOption.logFunction = LAppPal.printMessage;
        this._cubismOption.loggingLevel = LAppDefine.CubismLoggingLevel;
        CubismFramework.startUp(this._cubismOption);
        //-

        //フレームワーク初期化
        // initialize cubism
        CubismFramework.initialize();

        // load model
        LAppLive2DManager.getInstance(); //モデルの動作とイベント反応を管理するクラス//サンプルアプリケーションにおいてCubismModelを管理するクラス モデル生成と破棄、タップイベントの処理、モデル切り替えを行う

        LAppPal.updateTime(); //LAppPalクラスがデルタタイムを保持

        this._view?.initializeSprite(); //
    }

    /**
     * Resize the canvas to fill the screen.
     */
    private _resizeCanvas(): void {
        if (canvas != null) {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        }
    }

    //------------------話すの開始
    public onSpeakStart(): void {
        LAppLive2DManager.getInstance().speakStart();
    }

    public onSpeakStop(): void {
        LAppLive2DManager.getInstance().speakStop();
    }

    public addEventListener(event: "start", listner: Function) {
        switch (event) {
            case "start":
                LAppLive2DManager.getInstance().addEventListener(event, listner);
                return listner;
        }
    }

    /**
     * コンストラクタ
     */
    constructor() {
        this._captured = false; //クリックしているか
        this._mouseX = 0.0;
        this._mouseY = 0.0;
        this._isEnd = false;
        this._intervalId = null;

        this._cubismOption = new Option(); //ログ出力関連 Frameworkない
        this._view = new LAppView(); //描画クラス。
        this._textureManager = new LAppTextureManager(); //テクスチャ管理クラス 画像読み込み、管理を行うクラス。

        this._isRunning = false;
    }

    _cubismOption: Option; // Cubism SDK Option
    _view: LAppView | null; // View情報
    _captured: boolean; // クリックしているか
    _mouseX: number; // マウスX座標
    _mouseY: number; // マウスY座標
    _isEnd: boolean; // APP終了しているか
    _textureManager: LAppTextureManager | null; // テクスチャマネージャー
    _intervalId: NodeJS.Timer | null;
    _isRunning: boolean;
}
//-------------------------------------------------------------------------------------------------

/**
 * クリックしたときに呼ばれる。
 */
function onClickBegan(e: MouseEvent): void {
    if (!LAppDelegate.getInstance()._view) {
        LAppPal.printMessage("view notfound");
        return;
    }
    LAppDelegate.getInstance()._captured = true;

    const posX: number = e.pageX;
    const posY: number = e.pageY;

    LAppDelegate.getInstance()._view?.onTouchesBegan(posX, posY);
}

/**
 * マウスポインタが動いたら呼ばれる。
 */
function onMouseMoved(e: MouseEvent): void {
    if (!LAppDelegate.getInstance()._captured) {
        return;
    }

    if (!LAppDelegate.getInstance()._view) {
        LAppPal.printMessage("view notfound");
        return;
    }

    const rect = (e.target as Element).getBoundingClientRect();
    const posX: number = e.clientX - rect.left;
    const posY: number = e.clientY - rect.top;

    LAppDelegate.getInstance()._view?.onTouchesMoved(posX, posY);
}

/**
 * クリックが終了したら呼ばれる。
 */
function onClickEnded(e: MouseEvent): void {
    LAppDelegate.getInstance()._captured = false;
    if (!LAppDelegate.getInstance()._view) {
        LAppPal.printMessage("view notfound");
        return;
    }

    const rect = (e.target as Element).getBoundingClientRect();
    const posX: number = e.clientX - rect.left;
    const posY: number = e.clientY - rect.top;

    LAppDelegate.getInstance()._view?.onTouchesEnded(posX, posY);
}
/**
 * クリックが終了したら呼ばれる。
 */
function onClick(e: MouseEvent): void {
    LAppDelegate.getInstance()._captured = false;
    if (!LAppDelegate.getInstance()._view) {
        LAppPal.printMessage("view notfound");
        return;
    }

    const rect = (e.target as Element).getBoundingClientRect();
    const posX: number = e.clientX - rect.left;
    const posY: number = e.clientY - rect.top;

    LAppDelegate.getInstance()._view?.onTouchesBegan(posX, posY);
    LAppDelegate.getInstance()._view?.onTouchesEnded(posX, posY);
}
/**
 * クリックが終了したら呼ばれる。
 */
function onMouseRemoved(e: MouseEvent): void {
    LAppDelegate.getInstance()._captured = false;
    if (!LAppDelegate.getInstance()._view) {
        LAppPal.printMessage("view notfound");
        return;
    }

    LAppDelegate.getInstance()._view?.onFront();
}

/**
 * タッチしたときに呼ばれる。
 */
function onTouchBegan(e: TouchEvent): void {
    if (!LAppDelegate.getInstance()._view) {
        LAppPal.printMessage("view notfound");
        return;
    }

    LAppDelegate.getInstance()._captured = true;

    const posX = e.changedTouches[0].pageX;
    const posY = e.changedTouches[0].pageY;

    LAppDelegate.getInstance()._view?.onTouchesBegan(posX, posY);
}

/**
 * スワイプすると呼ばれる。
 */
function onTouchMoved(e: TouchEvent): void {
    if (!LAppDelegate.getInstance()._captured) {
        return;
    }

    if (!LAppDelegate.getInstance()._view) {
        LAppPal.printMessage("view notfound");
        return;
    }

    const rect = (e.target as Element).getBoundingClientRect();

    const posX = e.changedTouches[0].clientX - rect.left;
    const posY = e.changedTouches[0].clientY - rect.top;

    LAppDelegate.getInstance()._view?.onTouchesMoved(posX, posY);
}

/**
 * タッチが終了したら呼ばれる。
 */
function onTouchEnded(e: TouchEvent): void {
    LAppDelegate.getInstance()._captured = false;

    if (!LAppDelegate.getInstance()._view) {
        LAppPal.printMessage("view notfound");
        return;
    }

    const rect = (e.target as Element).getBoundingClientRect();

    const posX = e.changedTouches[0].clientX - rect.left;
    const posY = e.changedTouches[0].clientY - rect.top;

    LAppDelegate.getInstance()._view?.onTouchesEnded(posX, posY);
}

/**
 * タッチがキャンセルされると呼ばれる。
 */
function onTouchCancel(e: TouchEvent): void {
    LAppDelegate.getInstance()._captured = false;

    if (!LAppDelegate.getInstance()._view) {
        LAppPal.printMessage("view notfound");
        return;
    }

    const rect = (e.target as Element).getBoundingClientRect();

    const posX = e.changedTouches[0].clientX - rect.left;
    const posY = e.changedTouches[0].clientY - rect.top;

    LAppDelegate.getInstance()._view?.onTouchesEnded(posX, posY);
}
