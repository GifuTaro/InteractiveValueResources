/**
 * Copyright(c) Live2D Inc. All rights reserved.
 *
 * Use of this source code is governed by the Live2D Open Software license
 * that can be found at https://www.live2d.com/eula/live2d-open-software-license-agreement_en.html.
 */

// import { LogLevel } from "@framework/live2dcubismframework";

/**
 * Sample Appで使用する定数
 */

//canvasをcreateElementするのか、getElementするのか
//idはagentとする
export const Placement: "produce" | "get" = "get";

// Canvas width and height pixel values, or dynamic screen size ('auto').
//キャンバスサイズは固定
export const CanvasSize: { width: number; height: number } | "auto" = "auto";
//'auto'

// 画面
export const ViewScale = 1.0;
export const ViewMaxScale = 2.0;
export const ViewMinScale = 0.8;

export const ViewLogicalLeft = -1.0;
export const ViewLogicalRight = 1.0;
export const ViewLogicalBottom = -1.0;
export const ViewLogicalTop = 1.0;

export const ViewLogicalMaxLeft = -2.0;
export const ViewLogicalMaxRight = 2.0;
export const ViewLogicalMaxBottom = -2.0;
export const ViewLogicalMaxTop = 2.0;

//----------------モデルの拡大率と位置
export const myScale = 3.0;
export const myLocation: [number, number] = [0.0, -1.7];
/*
export const IdleMotions = {
    0:"顔を上下に揺らし右上を見る",//待機モーション
    1:"不思義気に顔を傾け、最後ににっこり"//クリック、待機モーション
    2:"目を上向けに左右"//待機モーション
    3:"ひきげにする、まゆした、した目"
    4:"にっこりして大きく口を開ける"//
    5:"手をかかげる、最後ににっこり"
    6:"びっくり"//クリック
    7:"にっこりしつつ手を掲げる"//くりっく
    8:"不満ぷく"
    9:"した目をむく"
}
*/

// //場面ごとのモーションの組み合わせ
// export const IdleMotions: number[] = [0, 1, 2, 4];
// export const SpeakMotions: number[] = [0, 2];
// export const TapMotions: number[] = [1, 6, 7];
// export type SceneNames = "idle" | "tap" | "speak";

//フレームレート
export const flameRate: number = 50;

//話す速度
export const speekSpeed: number = 1.0;

// 相対パス
////このスクリプトを読み込む「html」が配置される場所から、ソースへの相対位置ディレクトリ関係
export let ResourcesPath = ""; //https://cdn.jsdelivr.net/gh/hyokonbanwa/InteractiveValueResources@main/Resources/";
export const setPath = (path: string): void => {
    ResourcesPath = path;
};

// モデルの後ろにある背景の画像ファイル
//https://www.pixiv.net/artworks/13563186
export const BackImageName = "img/back_class_normal.png"; //"img/フリー素材_背景_学校廊下.png"; //"img/back_class_normal.png";

// // 歯車
// export const GearImageName = "img/icon_gear.png";

// //ロゴ
// export const LogoImageName = "img/Live2DLogo.png";

// // 終了ボタン
// export const PowerImageName = "img/CloseNormal.png";

// モデル定義---------------------------------------------
// モデルを配置したディレクトリ名の配列
// ディレクトリ名とmodel3.jsonの名前を一致させておくこと
export const ModelDir: string[] = ["Hiyori"]; //['Haru', 'Hiyori', 'Mark', 'Natori', 'Rice'];
export const ModelDirSize: number = ModelDir.length;

// 外部定義ファイル（json）と合わせる
export const MotionGroupIdle = "Idle"; // アイドリング
export const MotionGroupTapBody = "TapBody"; // 体をタップしたとき
export const MotionGroupStartSpeak = "StartSpeak";
export const MotionGroupAll = "All";

// 外部定義ファイル（json）と合わせる
export const HitAreaNameHead = "Head";
export const HitAreaNameBody = "Body";

// モーションの優先度定数
export const PriorityNone = 0;
export const PriorityIdle = 1;
export const PriorityNormal = 2;
export const PriorityForce = 3;

// デバッグ用ログの表示オプション
export const DebugLogEnable = true;
export const DebugTouchLogEnable = false;

// // Frameworkから出力するログのレベル設定
// export const CubismLoggingLevel: LogLevel = LogLevel.LogLevel_Verbose;

// デフォルトのレンダーターゲットサイズ
export const RenderTargetWidth = 1900;
export const RenderTargetHeight = 1000;
