Qualtrics.SurveyEngine.addOnload(function () {
    // 埋め込みデータ///////////////////////////////
    var item_num = 1;

    //ポイント
    var op_item1_point = 1;
    var op_item2_point = 1;
    var op_item3_point = 1;
    var op_item4_point = 1;

    var my_item1_point = 1;
    var my_item2_point = 1;
    var my_item3_point = 1;
    var my_item4_point = 1;

    var item1_max_num = 6;
    var item2_max_num = 5;
    var item3_max_num = 4;
    var item4_max_num = 3;

    //始めのひよりの個数
    var item1_num = 0;
    var item2_num = 0;
    var item3_num = 0;
    var item4_num = 0;

    //自分の個数
    var my_item1_num;
    var my_item2_num;
    var my_item3_num;
    var my_item4_num;

    //var facial_attenuation = "${e://Field/facial_attenuation}";//表情減衰係数(0～1)
    var facial_attenuation = 1;

    var limit = 1;

    //要因１　表情(0:False, 1:True)
    var f_emo = 1;
    //要因２　瞬き(0:False, 1:True)
    var f_bli = 1;
    console.log("FF: ", f_emo + "//" + f_bli);

    ///////////////////////////////////////////////////////

    var hsize = $(window).height();
    var wsize = $(window).width();
    var slider_div_size = $("#slider_div").width();
    var slider_div_half = slider_div_size / 2;
    console.log("slider_half=" + slider_div_size);

    // $('#slider_zone1').css({transform: 'rotate('+rotate1+'deg)'});

    // $('#slider_zone2').css({transform: 'rotate('+rotate2+'deg)'});
    // $('#slider_zone3').css({transform: 'rotate('+rotate3+'deg) scale(1,-1)'});
    // $('#slider_zone4').css({transform: 'rotate('+rotate4+'deg) scale(1,-1)'});

    //画面の中心
    var center = wsize / 2;
    var slider_interval;

    //line
    $("#line").css("left", Number(center) + "px");

    //スライダー配置
    for (var i = 1; i < item_num + 1; i++) {
        $("#slider_div").append(
            '<div class="slider_zone" id="slider_zone' +
                i +
                '"><div class="item_image item' +
                i +
                '_image op_item" id="item' +
                i +
                '_image_op"></div><input type="range" class="slider item' +
                i +
                '" id="item' +
                i +
                '" min="0"><div class="item_image item' +
                i +
                '_image my_item" id="item' +
                i +
                '_image_my"></div>'
        );

        //スライダー間隔
        slider_interval = $(".item_image").width();

        //アイテムが偶数個の時
        if (item_num % 2 == 0) {
            //スライダーの初期位置
            var position1 = slider_interval / 2 + center - slider_interval * (item_num / 2);
            $("#slider_zone" + i).css("left", position1 + slider_interval * (i - 1) + "px");
        }
        //アイテムが奇数個の時
        else {
            var position1 = center - slider_interval * Math.floor(item_num / 2);
            $("#slider_zone" + i).css("left", position1 + slider_interval * (i - 1) + "px");
        }
    }
    $("#slider_zone1").css("background-color", "red");
    $("#slider_zone2").css("background-color", "blue");
    $("#slider_zone3").css("background-color", "yellow");
    $("#slider_zone4").css("background-color", "green");

    for (var i = 1; i < item_num + 1; i++) {
        $("#item" + i).attr("max", eval("item" + i + "_max_num"));
        $("#item" + i).attr("value", eval("item" + i + "_max_num"));
    }

    $("#all").css("height", hsize + "px");
    //スライダーの長さの基準
    var len = hsize * 0.25;
    // $("#item1").css("width", len/Math.cos(deg_to_rad(rotate1-90))+"px");
    // $("#item2").css("width", len/Math.cos(deg_to_rad(rotate2-90))+"px");
    // $("#item3").css("width", len/Math.cos(deg_to_rad(rotate3-90))+"px");
    // $("#item4").css("width", len/Math.cos(deg_to_rad(rotate4-90))+"px");

    function deg_to_rad(degree) {
        var rad = degree * (Math.PI / 180);
        return rad;
    }

    var image_y;
    //表情変化用タイマー用変数
    var timeSet;
    //表情減衰用タイマー変数
    var facial_time;

    //台
    //https://dev-lib.com/how-to-css-trapezoid/
    //幅
    var width = slider_interval * item_num + 300;
    var table_height = $("#slider_zone1").width() + 100;
    var table_decrease = 100;

    $("#table").css("width", width + "px");
    $("#table").css("border-bottom", table_height + "px solid #EAEFF8");
    $("#table").css("left", center - width / 2 + "px");
    $("#table").css("border-left", table_decrease + "px solid transparent");
    $("#table").css("border-right", table_decrease + "px solid transparent");

    //スライダーバーの傾き
    var rotate1 = 90;
    var rotate2 = 90;
    var rotate3 = 90;
    var rotate4 = 90;
    var deg;
    for (i = 1; i < item_num + 1; i++) {
        console.log("position1=" + position1);
        deg = get_deg(position1 + slider_interval * (i - 1), width, table_height, center, table_decrease);
        console.log("deg=" + deg);
        eval("rotate" + i + "=deg+90");
        console.log("rotate=" + eval("rotate" + i));
        $("#slider_zone" + i).css({ transform: "rotate(" + eval("rotate" + i) + "deg)" });
        $(".item" + i + "_image").css({ transform: "rotate(" + eval("-rotate" + i) + "deg)" });
    }

    function get_deg(position, table_width, table_height, center, decrease) {
        var degree, rad;
        var y = (table_width * table_height) / (2 * decrease) - table_height;
        console.log("y=" + y);
        rad = Math.atan((center - position) / y);
        // rad = Math.atan(1/Math.sqrt(3));
        console.log("cent-posi=" + (center - position));
        degree = rad * (180 / Math.PI);
        return degree;
    }

    var elem = document.getElementById("image01");

    var image_array = [
        "https://rc1userv5pwvgnvtxbwj.au1.qualtrics.com/ControlPanel/Graphic.php?IM=IM_3n22ZNLhenTu29M", //プリン
        "https://rc1userv5pwvgnvtxbwj.au1.qualtrics.com/ControlPanel/Graphic.php?IM=IM_8rnZ1V9E9rHS2to", //さくらもち
        "https://rc1userv5pwvgnvtxbwj.au1.qualtrics.com/ControlPanel/Graphic.php?IM=IM_79Gb7gKuPZ7p794", //ドーナツ
        "https://rc1userv5pwvgnvtxbwj.au1.qualtrics.com/ControlPanel/Graphic.php?IM=IM_cItTHZCjxIUtQGO",
    ]; //ショートケーキ

    for (var i = 1; i < item_num + 1; i++) {
        for (var j = 1; j < eval("item" + i + "_max_num") + 1; j++) {
            $("#item" + i + "_image_op").append('<img id="op_image' + i + "_" + j + '" src="' + image_array[i - 1] + '" width="30" height="30" >');
            $("#op_image" + i + "_" + j).hide();
            $("#item" + i + "_image_my").append('<img id="my_image' + i + "_" + j + '" src="' + image_array[i - 1] + '" width="40" height="40" >');
            $("#my_image" + i + "_" + j).hide();
        }
    }

    //初期状態
    for (var i = 1; i < item_num + 1; i++) {
        for (var j = 1; j < eval("item" + i + "_num") + 1; j++) {
            $("#op_image" + i + "_" + j).show();
        }
        for (var j = 1; j < eval("item" + i + "_max_num-item" + i + "_num") + 1; j++) {
            $("#my_image" + i + "_" + j).show();
        }
    }

    //スライダー変更中
    $("#item1").on("input change", function () {
        for (i = 0; i < item1_max_num; i++) {
            $("#my_image1_" + (i + 1)).hide();
        }
        for (i = 0; i < item1_max_num; i++) {
            $("#op_image1_" + (i + 1)).hide();
        }

        stopFacialTimer();
        stopTimer();
        startTimer();
        my_item1_num = $(this).val();
        item1_num = item1_max_num - my_item1_num;

        for (i = 0; i < my_item1_num; i++) {
            $("#my_image1_" + (i + 1)).show();
        }
        for (i = 0; i < item1_num; i++) {
            $("#op_image1_" + (i + 1)).show();
        }

        total = get_op_total(item1_num, item2_num, item3_num, item4_num);
        faceDraw(total, f_emo, f_bli);
    });
    //変更後
    // $('#item1').change(function() {
    //   stopTimer();
    //   startTimer();
    // });
    $("#item2").on("input change", function () {
        for (i = 0; i < item2_max_num; i++) {
            $("#my_image2_" + (i + 1)).hide();
        }
        for (i = 0; i < item2_max_num; i++) {
            $("#op_image2_" + (i + 1)).hide();
        }

        stopFacialTimer();
        stopTimer();
        startTimer();
        my_item2_num = $(this).val();
        item2_num = item2_max_num - my_item2_num;

        for (i = 0; i < my_item2_num; i++) {
            $("#my_image2_" + (i + 1)).show();
        }
        for (i = 0; i < item2_num; i++) {
            $("#op_image2_" + (i + 1)).show();
        }

        total = get_op_total(item1_num, item2_num, item3_num, item4_num);
        faceDraw(total, f_emo, f_bli);
    });
    // $('#item2').change(function() {
    //   stopFacialTimer()
    //   stopTimer();
    //   startTimer();
    // });
    $("#item3").on("input change", function () {
        for (i = 0; i < item3_max_num; i++) {
            $("#my_image3_" + (i + 1)).hide();
        }
        for (i = 0; i < item3_max_num; i++) {
            $("#op_image3_" + (i + 1)).hide();
        }

        stopFacialTimer();
        stopTimer();
        startTimer();
        my_item3_num = $(this).val();
        item3_num = item3_max_num - my_item3_num;

        for (i = 0; i < my_item3_num; i++) {
            $("#my_image3_" + (i + 1)).show();
        }
        for (i = 0; i < item3_num; i++) {
            $("#op_image3_" + (i + 1)).show();
        }

        total = get_op_total(item1_num, item2_num, item3_num, item4_num);
        faceDraw(total, f_emo, f_bli);
    });
    // $('#item3').change(function() {
    //   stopTimer();
    //   startTimer();
    // });
    $("#item4").on("input change", function () {
        for (i = 0; i < item4_max_num; i++) {
            $("#my_image4_" + (i + 1)).hide();
        }
        for (i = 0; i < item4_max_num; i++) {
            $("#op_image4_" + (i + 1)).hide();
        }

        stopFacialTimer();
        stopTimer();
        startTimer();
        my_item4_num = $(this).val();
        item4_num = item4_max_num - my_item4_num;

        for (i = 0; i < my_item4_num; i++) {
            $("#my_image4_" + (i + 1)).show();
        }
        for (i = 0; i < item4_num; i++) {
            $("#op_image4_" + (i + 1)).show();
        }

        total = get_op_total(item1_num, item2_num, item3_num, item4_num);
        faceDraw(total, f_emo, f_bli);
    });
    // $('#item4').change(function() {
    //   stopTimer();
    //   startTimer();
    // });

    function get_op_total(item1, item2, item3, item4) {
        var total = item1 * op_item1_point + item2 * op_item2_point + item3 * op_item3_point + item4 * op_item4_point;
        return total;
    }

    var Face_Attenuate = function () {
        //表情減衰関数
        console.log("TimerFire!");
        total = get_op_total(item1_num, item2_num, item3_num, item4_num);

        var face_num = Math.ceil(facial_attenuation * (i_array_1.length - 1)); //変換係数
        console.log("face_num=" + face_num);

        for (i = 0; i < face_num - 1; i++) {
            (function (arg) {
                facial_time = setTimeout(function () {
                    image_y -= Math.ceil((i_array_1.length - 1) / face_num);
                    if (image_y < 2) {
                        image_y = 1;
                        console.log("image_y=" + image_y);
                        var center_i = i_array_1[image_y];
                        elem.src = center_i;
                        console.log("center_i=" + center_i);
                        return;
                    } else {
                        console.log("image_y=" + image_y);
                        var center_i = i_array_c_1[image_y];
                    }
                    console.log("center_i=" + center_i);
                    elem.src = center_i;
                }, arg * 100);
            })(i);
        }
        // if (total > limit){
        //   var answer = rnd_ar(); //0 or 1 or 2
        //   if(f_emo == 0) { // face no move.
        //     if( f_bli == 0) { // blink no
        //       var center_i = i_array_c_0[0];
        //     }
        //     else { //blink yes
        //       if (answer == 0) {
        //         var center_i = i_array_0[0];
        //       }
        //       else {
        //         var center_i = i_array_c_0[0];
        //       };
        //     }
        //   }
        //   else {
        //     if( f_bli == 0) { //blink no
        //       var center_i = i_array_c_1[1];
        //     }
        //     else if(answer == 0) {
        //       var center_i = i_array_1[1];
        //     }
        //     else {
        //       var center_i = i_array_c_1[1];
        //     };
        //   }
        // }
        // else{
        //   var center_i = i_array_c_1[0];
        // }

        // elem.src = center_i;
    };

    var milsec = 3700;
    function stopTimer() {
        clearTimeout(timeSet);
    }
    function startTimer() {
        // if(facial_attenuation==1){
        if (f_emo == 1) {
            timeSet = setTimeout(Face_Attenuate, milsec);
        }
        // }
    }

    function stopFacialTimer() {
        clearTimeout(facial_time);
    }
    // var timeSet = setTimeout(Face_Attenuate, milsec);

    //表情をセット
    var gen_x2 = 640;
    var gen_y2 = 400;
    var i_array_0 = ["https://rc1userv5pwvgnvtxbwj.au1.qualtrics.com/ControlPanel/Graphic.php?IM=IM_emNADjqx7f5R2Fo"];

    var i_array_b_0 = [
        // b pattern
        "https://rc1userv5pwvgnvtxbwj.au1.qualtrics.com/ControlPanel/Graphic.php?IM=IM_emNADjqx7f5R2Fo",
    ];

    var i_array_c_0 = ["https://rc1userv5pwvgnvtxbwj.au1.qualtrics.com/ControlPanel/Graphic.php?IM=IM_0PMH2Jg0n8NFutg"];

    var i_array_1 = [
        //blink pattern A
        "https://rc1userv5pwvgnvtxbwj.au1.qualtrics.com/ControlPanel/Graphic.php?IM=IM_bsaT3g9KdB1XMDc", //angry

        "https://rc1userv5pwvgnvtxbwj.au1.qualtrics.com/ControlPanel/Graphic.php?IM=IM_emNADjqx7f5R2Fo", //1
        "https://rc1userv5pwvgnvtxbwj.au1.qualtrics.com/ControlPanel/Graphic.php?IM=IM_38hhwnYXQEzlP9k", //2
        "https://rc1userv5pwvgnvtxbwj.au1.qualtrics.com/ControlPanel/Graphic.php?IM=IM_bgvYouZey2lSb0a", //3
        "https://rc1userv5pwvgnvtxbwj.au1.qualtrics.com/ControlPanel/Graphic.php?IM=IM_22V1i488ri4uZdI", //4
        "https://rc1userv5pwvgnvtxbwj.au1.qualtrics.com/ControlPanel/Graphic.php?IM=IM_9pLIa3T1fkoA5wy", //5
        "https://rc1userv5pwvgnvtxbwj.au1.qualtrics.com/ControlPanel/Graphic.php?IM=IM_02HD8EOonQgvuOW", //6
        "https://rc1userv5pwvgnvtxbwj.au1.qualtrics.com/ControlPanel/Graphic.php?IM=IM_4MKqe2pG6H6KP9c", //7
        "https://rc1userv5pwvgnvtxbwj.au1.qualtrics.com/ControlPanel/Graphic.php?IM=IM_b89sEu4hhAIGcpE", //8
    ];

    var i_array_b_1 = [
        // b pattern
        "https://rc1userv5pwvgnvtxbwj.au1.qualtrics.com/ControlPanel/Graphic.php?IM=IM_bsaT3g9KdB1XMDc", //angry

        "https://rc1userv5pwvgnvtxbwj.au1.qualtrics.com/ControlPanel/Graphic.php?IM=IM_emNADjqx7f5R2Fo", //1
        "https://rc1userv5pwvgnvtxbwj.au1.qualtrics.com/ControlPanel/Graphic.php?IM=IM_38hhwnYXQEzlP9k", //2
        "https://rc1userv5pwvgnvtxbwj.au1.qualtrics.com/ControlPanel/Graphic.php?IM=IM_bgvYouZey2lSb0a", //3
        "https://rc1userv5pwvgnvtxbwj.au1.qualtrics.com/ControlPanel/Graphic.php?IM=IM_22V1i488ri4uZdI", //4
        "https://rc1userv5pwvgnvtxbwj.au1.qualtrics.com/ControlPanel/Graphic.php?IM=IM_9pLIa3T1fkoA5wy", //5
        "https://rc1userv5pwvgnvtxbwj.au1.qualtrics.com/ControlPanel/Graphic.php?IM=IM_02HD8EOonQgvuOW", //6
        "https://rc1userv5pwvgnvtxbwj.au1.qualtrics.com/ControlPanel/Graphic.php?IM=IM_4MKqe2pG6H6KP9c", //7
        "https://rc1userv5pwvgnvtxbwj.au1.qualtrics.com/ControlPanel/Graphic.php?IM=IM_b89sEu4hhAIGcpE", //8
    ];

    var i_array_c_1 = [
        // blibk no
        "https://rc1userv5pwvgnvtxbwj.au1.qualtrics.com/ControlPanel/Graphic.php?IM=IM_86cAcFStvlr5IWy", //angry

        "https://rc1userv5pwvgnvtxbwj.au1.qualtrics.com/ControlPanel/Graphic.php?IM=IM_0PMH2Jg0n8NFutg", //1
        "https://rc1userv5pwvgnvtxbwj.au1.qualtrics.com/ControlPanel/Graphic.php?IM=IM_bxX6lVvF9cLKbd4", //2
        "https://rc1userv5pwvgnvtxbwj.au1.qualtrics.com/ControlPanel/Graphic.php?IM=IM_cOQ3iAfniIMbwH4", //3
        "https://rc1userv5pwvgnvtxbwj.au1.qualtrics.com/ControlPanel/Graphic.php?IM=IM_eXV4titGtmILvjU", //4
        "https://rc1userv5pwvgnvtxbwj.au1.qualtrics.com/ControlPanel/Graphic.php?IM=IM_1SrLwXOC9G7hHam", //5
        "https://rc1userv5pwvgnvtxbwj.au1.qualtrics.com/ControlPanel/Graphic.php?IM=IM_diLYlJFhcJu4tNA", //6
        "https://rc1userv5pwvgnvtxbwj.au1.qualtrics.com/ControlPanel/Graphic.php?IM=IM_elB0Qvilyu5j5t4", //7
        "https://rc1userv5pwvgnvtxbwj.au1.qualtrics.com/ControlPanel/Graphic.php?IM=IM_3pDtcnipjhzgSXA", //8
    ];

    function rnd_ar() {
        //配列をランダムに入れ替える
        var rand = Math.floor(Math.random() * 9);
        var seed = rand % 3;
        return seed;
    }

    function faceDraw(yy, fact01, fact02) {
        //表情を描画する //yy=金額, fact01=表情, fact02=まばたき
        //yの変換

        //yの変換
        var sumitem = op_item1_point + op_item2_point + op_item3_point + op_item4_point;
        num = sumitem - (limit - 1); //変換係数
        //リミットを基準とした特典
        if (yy < limit) {
            image_y = 0;
        } else {
            image_y = Math.ceil(((yy - (limit - 1)) / num) * (i_array_1.length - 1));
            if (image_y >= i_array_1.length) {
                image_y = i_array_1.length - 1;
            }
        }
        //画像の取り出し
        var answer = rnd_ar(); //0 or 1 or 2
        if (fact01 == 0) {
            // face no move.
            if (fact02 == 0) {
                // blink no
                var center_i = i_array_c_0[0];
            } else {
                //blink yes
                if (answer == 0) {
                    var center_i = i_array_0[0];
                } else if (answer == 1) {
                    var center_i = i_array_b_0[0];
                } else {
                    var center_i = i_array_c_0[0];
                }
            }
        } else {
            if (fact02 == 0) {
                //blink no
                var center_i = i_array_c_1[image_y];
            } else if (answer == 0) {
                var center_i = i_array_1[image_y];
            } else if (answer == 1) {
                var center_i = i_array_b_1[image_y];
            } else {
                var center_i = i_array_c_1[image_y];
            }
        }
        console.log("Ans:", answer);
        console.log("F1/F2:", f_emo + "////" + f_bli);
        console.log("Indx:", image_y);
        console.log("face:", center_i);
        console.log("elem:", elem);
        elem.src = center_i;
    }

    //初期状態
    faceDraw(0, f_emo, f_bli);
    stopTimer();
});

Qualtrics.SurveyEngine.addOnReady(function () {
    /*ページが完全に表示されたときに実行するJavaScriptをここに配置してください*/
});

Qualtrics.SurveyEngine.addOnUnload(function () {
    /*ページの読み込みが解除されたときに実行するJavaScriptをここに配置してください*/
});
