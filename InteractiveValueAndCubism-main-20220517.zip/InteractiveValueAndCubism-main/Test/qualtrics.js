/*

1.結果の手に入れ方

結果を受け取るには
Qualtrics.SurveyEngine.addOnload(function()	{});の{}内で
「JSON.parse('${e://Field/sectionOneResult}');」を使う
シングルクオーテーション　SON.parse(' ')じゃないとエラーになる。

2.結果の内容
渡されるものは下記の例のようなオブジェクトの配列  [object,object...]
オブジェクトの数は4つ

例：

{
	foodName: "ナポリタン", // 食べ物の名前
	id: 9, // id 一意の値
	//食べ物の画像のpath
	path: "https://cdn.jsdelivr.net/gh/hyokonbanwa/InteractiveValueResources@bba47ac9bf7712262230846f0f204efa82302a95/Resources/foodImgs/0013_ナポリタン.jpg",
	score: 97, //1～100の得点
	use: 1, //得点　0～10なら-1、90～100なら1
}

3.具体的な使い方は次のブロックにあるので参考にしてください
*/
{
    let myLibrary = null;
    Qualtrics.SurveyEngine.addOnload(function () {
        const inputRange = document.getElementById("inputRange");
        const outputRange = document.getElementById("rangeOutput");
        inputRange.addEventListener("input", () => {
            outputRange.innerText = inputRange.value;
        });

        //画面の縦横100%にする
        const skinInner = document.querySelector(".SkinInner");
        skinInner.classList.add("expand-section1");

        //背景色
        //const jfe = document.querySelector(".JFE");
        //jfe.classList.add("bg-danger");

        //次ボタンを隠す
        this.hideNextButton();

        //myLibrary用の値
        const resourcesPath = "https://cdn.jsdelivr.net/gh/hyokonbanwa/InteractiveValueResources@86ca8093b84b5ff550383ef4a090523eaefd9071/Resources/";
        const displayChart = "${e://Field/display}" === "true" ? true : false;

        //インスタンス作成＆DOMLoad操作
        myLibrary = new SectionOmote(resourcesPath, displayChart);
        myLibrary.onload();
        //確定ボタンが押されたときのリスナー登録
        myLibrary.addEventListener("finish", () => {
            console.log(myLibrary.getResult());
            //結果をJson文字列に変換して保存。使うときは「JSON.parse('${e://Field/sectionOneResult}');」を使う
            //シングルクオーテーション　SON.parse(' ')じゃないとエラーになる。
            Qualtrics.SurveyEngine.setEmbeddedData("sectionOneResult", JSON.stringify(myLibrary.getResult()));

            //スクリプトでつぎの質問に進める　画面遷移
            jQuery("#NextButton").click();
        });

        //console.log("${q://QID2/ChoiceGroup/SelectedChoices} ")
        //console.log(skinInner.style.width);
        //console.log(skinInner.style.height);
        /*ページが読み込まれたときに実行するJavaScriptをここに配置してください*/
    });

    Qualtrics.SurveyEngine.addOnReady(function () {
        //windowLoad時の操作

        myLibrary.onReady();
        /*ページが完全に表示されたときに実行するJavaScriptをここに配置してください*/
    });

    Qualtrics.SurveyEngine.addOnUnload(function () {
        //windowUnLoad時の操作
        myLibrary.onUnload();
        /*ページの読み込みが解除されたときに実行するJavaScriptをここに配置してください*/
    });
}

/*

1.結果の手に入れ方

結果を受け取るには
Qualtrics.SurveyEngine.addOnload(function()	{});の{}内で
「JSON.parse('${e://Field/sectionOneResult}');」を使う
シングルクオーテーション　SON.parse(' ')じゃないとエラーになる。

2.結果の内容
渡されるものは下記の例のようなオブジェクトの配列  [object,object...]
オブジェクトの数は4つ

例：

{
	foodName: "ナポリタン", // 食べ物の名前
	id: 9, // id 一意の値
	//食べ物の画像のpath
	path: "https://cdn.jsdelivr.net/gh/hyokonbanwa/InteractiveValueResources@bba47ac9bf7712262230846f0f204efa82302a95/Resources/foodImgs/0013_ナポリタン.jpg",
	score: 97, //1～100の得点
	use: 1, //得点　0～10なら-1、90～100なら1
}

3.具体的な使い方は次のブロックにあるので参考にしてください

    var qthis = this;
    qthis.hideNextButton();
 
    var task_github = "https://自分のサーバーのアドレス/フォルダ名/""; 
 
    var requiredResources = [
        task_github + "jspsych-6.1.0/jspsych.js",
        task_github + "jspsych-6.1.0/plugins/jspsych-html-keyboard-response.js",
        task_github + "jspsych-6.1.0/plugins/jspsych-image-keyboard-response.js",
        task_github + "main.js"
    ];
 
    function loadScript(idx) {
        console.log("Loading ", requiredResources[idx]);
        jQuery.getScript(requiredResources[idx], function () {
            if ((idx + 1) < requiredResources.length) {
                loadScript(idx + 1);
            } else {
                initExp();
            }
        });
    }

    <!-- Section1 表の使用している読み込みファイル !--><script defer src="https://unpkg.com/core-js-bundle@3.6.1/minified.js"></script>
    <script defer src="https://cdn.jsdelivr.net/gh/hyokonbanwa/InteractiveValueResources@86ca8093b84b5ff550383ef4a090523eaefd9071/Resources/Core/live2dcubismcore.js">
    </script><script defer src="https://cdn.jsdelivr.net/gh/hyokonbanwa/InteractiveValueResources@0bca7a5ca615478f039fcb6f2c537a047fc3abb5/js/SectionOmote.js"></script>
    <link href="https://cdn.jsdelivr.net/gh/hyokonbanwa/InteractiveValueResources@86ca8093b84b5ff550383ef4a090523eaefd9071/css/SectionOmote.css" rel="stylesheet" /><!-- Section1 表の使用している読み込みファイル !-->
*/

{
    let myLibrary = null;
    Qualtrics.SurveyEngine.addOnload(function () {
        // const cssLink = document.createElement("link");
        // const cssPlace = document.getElementById("cssPlace");
        // // <link id="PageStyleSheet" rel="stylesheet" href="Style1.css" />
        // cssLink.href = "https://cdn.jsdelivr.net/gh/hyokonbanwa/InteractiveValueResources@0bca7a5ca615478f039fcb6f2c537a047fc3abb5/" + "css/SectionOmote.css";
        // cssLink.rel = "stylesheet";
        // cssPlace.appendChild(cssLink);
        const inputRange = document.getElementById("inputRange");
        const outputRange = document.getElementById("rangeOutput");
        inputRange.addEventListener("input", () => {
            outputRange.innerText = inputRange.value;
        });

        //画面の縦横100%にする
        const skinInner = document.querySelector(".SkinInner");
        skinInner.classList.add("expand-section1");

        //背景色
        //const jfe = document.querySelector(".JFE");
        //jfe.classList.add("bg-danger");
        //次ボタンを隠す
        this.hideNextButton();

        const resourcesRoot = "https://cdn.jsdelivr.net/gh/hyokonbanwa/InteractiveValueResources@314b41d7013a67b7460c1aba0509061ce9d85607/";
        const requiredResources = ["https://unpkg.com/core-js-bundle@3.6.1/minified.js", resourcesRoot + "Resources/Core/live2dcubismcore.js", resourcesRoot + "js/SectionOmote.js"];

        const loadScript = (idx) => {
            console.log("Loading ", requiredResources[idx]);
            jQuery.getScript(requiredResources[idx], function () {
                if (idx + 1 < requiredResources.length) {
                    loadScript(idx + 1);
                } else {
                    initExp();
                }
            });
        };

        const initExp = () => {
            //myLibrary用の値
            const resourcesPath = resourcesRoot + "Resources/";
            const displayChart = "${e://Field/display}" === "true" ? true : false;

            //インスタンス作成＆DOMLoad操作
            myLibrary = new SectionOmote(resourcesPath, displayChart);
            myLibrary.onload();
            //確定ボタンが押されたときのリスナー登録
            myLibrary.addEventListener("finish", () => {
                console.log(myLibrary.getResult());
                //結果をJson文字列に変換して保存。使うときは「JSON.parse('${e://Field/sectionOneResult}');」を使う
                //シングルクオーテーション　SON.parse(' ')じゃないとエラーになる。
                Qualtrics.SurveyEngine.setEmbeddedData("sectionOneResult", JSON.stringify(myLibrary.getResult()));

                //スクリプトでつぎの質問に進める　画面遷移
                jQuery("#NextButton").click();
            });

            myLibrary.onReady();

            //console.log("${q://QID2/ChoiceGroup/SelectedChoices} ")
            //console.log(skinInner.style.width);
            //console.log(skinInner.style.height);
        };

        console.log("スクリプト読み込み");
        loadScript(0);

        /*ページが読み込まれたときに実行するJavaScriptをここに配置してください*/
    });

    Qualtrics.SurveyEngine.addOnReady(function () {
        //windowLoad時の操作
        console.log("window");

        // if (myLibrary != null) {
        //     myLibrary.onReady();
        // }
        /*ページが完全に表示されたときに実行するJavaScriptをここに配置してください*/
    });

    Qualtrics.SurveyEngine.addOnUnload(function () {
        //windowUnLoad時の操作
        if (myLibrary != null) {
            myLibrary.onUnload();
        }
        /*ページの読み込みが解除されたときに実行するJavaScriptをここに配置してください*/
    });
}
