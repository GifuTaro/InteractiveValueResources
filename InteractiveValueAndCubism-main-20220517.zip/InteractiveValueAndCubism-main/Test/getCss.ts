const skinInner = document.querySelector(".SkinInner") as HTMLElement;
console.log(getComputedStyle(skinInner));
const cssLink = document.createElement("link");
const cssPlace = document.getElementById("cssPlace");
// <link id="PageStyleSheet" rel="stylesheet" href="Style1.css" />
cssLink.href = "https://cdn.jsdelivr.net/gh/hyokonbanwa/InteractiveValueResources@86ca8093b84b5ff550383ef4a090523eaefd9071/" + "css/SectionOmote.css";
cssLink.rel = "stylesheet";
cssPlace.appendChild(cssLink);
