/**
 * 目的：src/Resources/foodImgs以下の特定のファイル名を抽出し、jsonファイルを作成する
 * src/Resources/json以下にfoodNames.jsonというファイルを作成する。
 */

import * as fs from "fs";
import * as path from "path";
export {};
// カレントディレクトリ
const src: string = path.resolve(__dirname, "../src/Resources/foodImgs");
//console.log(__dirname);

fs.readdir(src, (error: NodeJS.ErrnoException | null, files: string[]) => {
    if (error) {
        console.log(error);
    } else {
        console.log(files);
        const matches: string[] = files.filter((currentValue: string, index: number, array: string[]) => {
            return currentValue.search(/^\d{4}_.*\.(eot|svg|ttf|woff|woff2|png|jpg|gif)$/) === 0;
        });
        console.log(matches);
        console.log(JSON.stringify(matches));
        const options = {
            flag: "w",
        };
        fs.writeFile(path.resolve(__dirname, "../src/Resources/json/foodNames.json"), JSON.stringify(matches), options, (error: NodeJS.ErrnoException | null) => {
            // 書き出しに失敗した場合
            if (error) {
                console.log("エラーが発生しました。" + error);
            }
            // 書き出しに成功した場合
            else {
                console.log("ファイルが正常に書き出しされました");
            }
        });
    }
});
