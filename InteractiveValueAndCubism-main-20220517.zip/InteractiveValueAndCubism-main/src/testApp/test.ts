import "../css/test.css";
import App from "./App";

{
    console.log("Appマウント");
    App();
    //localStorage.removeItem("results");
}
