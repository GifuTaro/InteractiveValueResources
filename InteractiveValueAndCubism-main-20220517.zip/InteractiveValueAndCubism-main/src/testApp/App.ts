export default () => {
    console.log(JSON.parse(localStorage.getItem("results") as string));
};
