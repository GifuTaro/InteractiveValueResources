// import * as IndexDefine from "./indexDefine";
// export{};
// console.log(IndexDefine.ResourcesPath);
// IndexDefine.changePath();
// console.log(IndexDefine.ResourcesPath);
