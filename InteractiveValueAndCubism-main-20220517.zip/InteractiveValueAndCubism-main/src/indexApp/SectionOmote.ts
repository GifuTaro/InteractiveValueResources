//スタイルシート読み込み
import "../css/index.scss";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";
import "bootstrap";
import * as bootstrap from "bootstrap";

// //<!-- Pollyfill script -->以下の代わりに読み込む
// //import "https://unpkg.com/core-js-bundle@3.6.1/minified.js";
// //import "../Resources/Core/live2dcubismcore";

//メインアプリ読み込み
import { App } from "./App";
import { SectionState, FinalResult } from "./myTypes";
// import { LAppDelegate } from "../../cubism/lappdelegate";
import * as IndexDefine from "./indexDefine";
// import * as LappDefine from "../../cubism/lappdefine";

// {
//     /*BootstrapTooltip使うときに有効化
//     const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
//     const popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
//         return new bootstrap.Popover(popoverTriggerEl);
//     });
//     */

//     //-- App初期化
//     //let app: App | null = null;
//     const app: App = new App();
//     app.mount();
//     /* app = new App();
//     app.mount(); */
//     //-

//     /* document.addEventListener(
//         "DOMContentLoaded",
//         (): void => {
//             app = new App();
//             app.mount();
//         },
//         false
//     ); */

//     //--- cubism SDK 初期化
//     window.addEventListener(
//         "load",
//         () => {
//             LAppDelegate.getInstance().initialize();
//             LAppDelegate.getInstance().run();

//             //-ロード画面とコンテンツ表示切替
//             const loading = document.getElementById("loading") as HTMLElement; //ロード中に表示するコンテンツ
//             const contents = document.getElementById("contents") as HTMLElement; //ロード後に表示するコンテンツ
//             const parent = loading.parentNode as HTMLElement;
//             // 読み込みが完了したら#contentsを表示して#loadingとその親要素を非表示に

//             loading.classList.add("d-none");
//             parent.classList.replace("vh-100", "d-none");
//             contents.classList.remove("d-none");
//         },
//         false
//     );
//     //-

//     // window.onload = () => {
//     //     app = new App();
//     //     app.mount();
//     // };

//     //document.addEventListener("DOMContentLoaded", () => {});

//     //--ページ終了時の処理
//     window.addEventListener("beforeunload", () => {
//         app.unmount();
//     });
//     //-
// }

export default class SectionOmote {
    private app: App | null;

    constructor(path: string, serverURL: string, chart: boolean) {
        IndexDefine.setPath(path);
        IndexDefine.setServerURL(serverURL);
        IndexDefine.setChart(chart);
        this.app = null;
        //LappDefine.setPath(path);
    }
    onload = () => {
        console.log("DOMLoadedAction");
        this.app = new App();
        this.app.mount();
        this.app.sectionModel.myCanvas.onLoadFinished(() => {
            //-ロード画面とコンテンツ表示切替
            const loading = document.getElementById("loading") as HTMLElement; //ロード中に表示するコンテンツ
            const contents = document.getElementById("contents") as HTMLElement; //ロード後に表示するコンテンツ
            const parent = loading.parentNode as HTMLElement;
            //読み込みが完了したら#contentsを表示して#loadingとその親要素を非表示に

            loading.classList.add("d-none");
            parent.classList.replace("vh-100", "d-none");
            contents.classList.remove("d-none");

            console.log("Live2D読み込み完了");
        });
    };
    onReady = () => {
        console.log("WindowLoadedAction");
        // console.log(screen.width, screen.height);
        // const agentCanvas = document.getElementById("agent") as HTMLCanvasElement;
        // const width: string = String(500 * (screen.width / 2560));
        // const height: string = String(500 * (screen.height / 1440));
        // agentCanvas.setAttribute("width", width);
        // agentCanvas.setAttribute("height", height);
    };
    onUnload = () => {
        this.app?.unmount();
    };
    getResult = (): FinalResult[] | never => {
        if (this.app != null) {
            return this.app.sectionModel.finalResults;
        } else {
            throw new Error("Appが存在しません");
        }
    };
    addEventListener(event: "finish", callback: Function) {
        switch (event) {
            case "finish":
                const decideButton = document.getElementById("decideButton") as HTMLInputElement;
                decideButton.addEventListener("click", (event: MouseEvent): void => {
                    event.preventDefault();
                    if (this.app === null) return;
                    if (this.app.sectionModel.state === SectionState.ItemCollected) {
                        //this.dismount();
                        callback();
                    }
                });
                break;
        }
    }
}

// export default class{
//     func1 = ()=>{
//         console.log("func1");
//     }
//     func2 = (i:string)=>{
//         console.log(i);
//         this.iii = i;
//     }
// 	aaa = '111'
//     iii = "first"
// };
