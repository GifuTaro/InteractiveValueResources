//import { Chart, ChartConfiguration, registerables } from "chart.js";
//import * as Chartjs from "chart.js";
import { SectionModel } from "./SectionModel";
import { ChartModel } from "./ChartModel";
import { BubbleModel } from "./BubbleModel";
import { SectionItem, ChartUses, SectionState, ModelPosition } from "./myTypes";
//import { LAppDelegate } from "../cubism/lappdelegate";
import * as IndexDefine from "./indexDefine";
import { MyCanvas } from "./MyCanvas";
// import * as PIXI from "pixi.js";

//import foodNames from "../Resources/json/foodNames.json";

//import myCsv from "./csv/foodName.csv"; //ここでCsvファイルをインクルード pathとしてインポートされる

export class App {
    private chartModel: ChartModel;
    public sectionModel: SectionModel;
    private bubbleModel: BubbleModel;
    private idNum: number;
    private myCanvas: MyCanvas;
    private serverURL: string;
    //public cubismLoaded: boolean;

    constructor() {
        const modelPosition: ModelPosition = { boxWidth: 500, boxHeight: 500, modelScale: 0.45, modelX: 0, modelY: 550 };
        this.chartModel = new ChartModel();
        this.bubbleModel = new BubbleModel();
        this.myCanvas = new MyCanvas(false, IndexDefine.ResourcesPath + "Hiyori_2/Hiyori.model3.json", modelPosition);
        this.sectionModel = new SectionModel(this.bubbleModel, this.chartModel, this.myCanvas);
        this.idNum = 0;
        this.serverURL = IndexDefine.ServerURL;

        //this.cubismLoaded = false;
    }
    mount = async () => {
        /*
        console.log(__filename);
        console.log(__dirname);
        */
        console.log("Appマウント");
        //windowAudioContext構成
        window.AudioContext = window.AudioContext ?? window.webkitAudioContext;

        this.myCanvas.initialize();

        if (IndexDefine.DisplayChart === false) {
            const chartBox = document.getElementById("graph") as HTMLElement;
            const formBox = document.getElementById("input") as HTMLElement;
            chartBox.classList.add("d-none");
            formBox.classList.add("mx-auto");
            formBox.classList.remove("col-xl-3");
            formBox.classList.add("col-xl-4");
        }

        const inputButton = document.getElementById("inputButton") as HTMLElement;
        const inputRange = document.getElementById("inputRange") as HTMLInputElement;
        const backButton = document.getElementById("backButton") as HTMLElement;
        //const start = document.getElementById("speak") as HTMLInputElement;
        //const stop = document.getElementById("stop") as HTMLInputElement;
        const decideButton = document.getElementById("decideButton") as HTMLInputElement;

        //--マウント時にモデルにレンダーを設定する
        this.sectionModel.onComplete(this.sectionModel.finidhRender);

        this.sectionModel.onLack(this.sectionModel.lackRender);

        this.bubbleModel.onCreate(this.bubbleModel.createRender);
        this.bubbleModel.onChange(this.bubbleModel.changeRender);
        this.bubbleModel.onComplete(this.bubbleModel.completeRender);

        this.chartModel.onCreate(this.chartModel.createRender);

        this.chartModel.onChange(this.chartModel.changeRender);
        //-

        //--要素にイベント設定
        inputButton.addEventListener("click", (event: MouseEvent): void => {
            event.preventDefault();

            //this.cubismLoaded = LAppDelegate.isRunning(); //----cubisnランニング中か確認
            //Live2dデータ読み取りに成功したか
            //if (this.cubismLoaded === true) {
            //モデルに最初のアイテム表示されていないならなら
            if (this.sectionModel.state === SectionState.Staying) {
                this.sectionModel.sectionStart();
            }
            //モデルがアイテム収集中なら
            else if (this.sectionModel.state == SectionState.ModelIlde) {
                //const useResults = this.sectionModel.useResults;
                //console.log(useResults.length);
                const content: SectionItem = this.sectionModel.getCurrentContent();
                let useTmp: ChartUses | null = null;
                const score: number = parseInt(inputRange.value);
                if (Number.isNaN(score) === false) {
                    if (score >= 90) {
                        useTmp = 1;
                    } else if (score <= 10) {
                        useTmp = -1;
                    } else {
                        useTmp = 0;
                    }
                }
                const use = useTmp as ChartUses;
                this.sectionModel.sectionNext({
                    id: this.idNum,
                    foodName: content.foodName,
                    path: content.path,
                    score: score,
                    use: use,
                });
                this.idNum += 1;
            }
            //}
        });

        backButton.addEventListener("click", (event: MouseEvent): void => {
            event.preventDefault();
            if (this.sectionModel.sectionNum != null) {
                if (this.sectionModel.sectionNum > 0) {
                    this.sectionModel.sectionBack();
                }
            }
        });
        //--

        /*
        start.addEventListener("click", (event: Event): void => {
            event.preventDefault();
            console.log("クリックしたぜ");
            LAppDelegate.getInstance().onSpeakStart();
        });
        stop.addEventListener("click", (event: Event): void => {
            event.preventDefault();
            LAppDelegate.getInstance().onSpeakStop();
        });
        */

        decideButton.addEventListener("click", (event: MouseEvent): void => {
            event.preventDefault();

            //     if (this.sectionModel.state === SectionState.ItemCollected) {
            //         localStorage.setItem("results", JSON.stringify(this.sectionModel.finalResults));
            //         this.unmount();
            //         location.href = "/test.html";
            //         //this.dismount();
            //     }
        });

        const serverConnect = await this.myCanvas.testConnect(this.serverURL);
        this.bubbleModel.setServerConnect(serverConnect);
    };

    unmount(): void {
        //LAppDelegate.releaseInstance();
    }
}
