export let ResourcesPath: string = "";
export let ServerURL: string = "";
export let DisplayChart: boolean = false;

export const PositiveNum: number = 2;

export const NegativeNum: number = 2;

export const ChartLength: number = 5;

export const setPath = (path: string): void => {
    ResourcesPath = path;
};
export const setChart = (bool: boolean): void => {
    DisplayChart = bool;
};

export const setServerURL = (url: string): void => {
    ServerURL = url;
};
