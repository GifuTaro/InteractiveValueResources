# 使い方

## プロジェクトの説明

-   「webpack」を利用しているプロジェクト　※公式サイト　https://webpack.js.org/<br>
-   使用している言語は「TypeScript・Javascript」のプロジェクト<br>
-   このプロジェクトで使われている Node.js のバージョンは「16.14.1LTS」<br>
-   このプロジェクトの使用方法は 4.使用方法に詳細

## 動作の説明

-   webpack で src 以下のファイル群をバンドルし dist 以下に出力する<br>
-   index.html で読み込んでいるファイルは index.js である。<br>
-   index.js は index.ts ファイル群をコンパイルしたものである。<br>
-   つまり index.ts に書いたコードが index.js にコンパイルされ index.html が取り込み表示している。<br>

※JavaScript で webpack 実行したい場合下記の URL を参考に行う<br>
https://ics.media/entry/12140/<br>

※TypeScript そのもの<br>

-   公式サイト　https://www.typescriptlang.org/docs/handbook/typescript-from-scratch.html<br>
    Wikipedia 　https://en.wikipedia.org/wiki/TypeScript<br>
-   日本語ドキュメント<br>
    &emsp;https://typescript-jp.gitbook.io/deep-dive/<br>
    &emsp;https://typescriptbook.jp/<br>
    &emsp;https://future-architect.github.io/typescript-guide/index.html<br>
    &emsp;http://typescript.ninja/typescript-in-definitelyland/index.html<br>
    &emsp;https://js.studio-kingdom.com/typescript/handbook/<br>
-   導入について<br>
    &emsp;https://typescriptbook.jp/overview/why-you-should-use-typescript<br>
    &emsp;https://engineering.linecorp.com/ja/blog/benefits-and-costs-to-consider-when-installing-typescript/<br>

### 0. 環境整備

(1). nvm for windows 　(Node.js のバージョン管理ソフト）をインストールする <br>
windows 版　https://docs.microsoft.com/ja-jp/windows/dev-environment/javascript/nodejs-on-windows<br>
※mac 版 nvm は「nvm mac」などで検索してください。<br>
mac 版　https://ralacode.com/blog/post/install-nodejs-with-nvm/<br>
※このプロジェクトで使われている Node.js のバージョンは「16.14.1LTS」<br>
※うまくいかないようなら直接 Node.js をインストールする

(2). プロジェクトのルートディレクトリ（package.json があるディレクトリ)にコマンドプロンプトで移動する。<br>
そして「npm install」を実行しこのプロジェクトが依存しているパッケージをインストールする<br>
※mac の場合このプロジェクトの改行コードは CRLF なので、LF に変更する<br>

### 1.コーディング

src 以下を起点としてプログラミングをしていく<br>
※直接 dist/index.js を編集しない、index.js はコンパイルされたファイル<br>
※html のスクリプトで読み込むソースファイルが index.ts であるとみなす<br>

### 2.ビルド（コンパイル）　&　実行

ターミナルでプロジェクトのルートディレクトリ（package.json があるディレクトリ)に移動し「npm run start-dev」と入力するとサーバーが立ち上がる。<br>
サーバーを立ち上げず、ファイルのビルドだけするときは「npm run build-dev」と入力する。<br>

※「npm run start-dev」の動作<br>
src ディレクトリ配下の index.ts ファイルを起点としてコンパイルし,dist ディレクトリ配下(./dist/js/index.js)に index.js としてコンパイルされる。<br>
そして index.html(./dist/index.html)がサーバー起動時に読み込まれ、その際 html ファイル内で指定した index.js を読み込んでいる。<br>

### 3.パッケージのインストール

ウェブサーバーの動作に必要なものはルートディレクトリで「npm install パッケージ名」<br>
動作に必要なく開発環境でしか必要ないものは「npm install --save-dev パッケージ名」<br>

### 4.このプロジェクトの使用方法

(1).「npm install」 node パッケージインストール<br>
(2).「npm run test-all」下記の make と start-dev を同時実行する<br>

※test-all の動作については下記のコマンドを順番に実行するのと同意<br>
「npm run make」 src/Resources/foodImges 以下の画像ファイル名にしたがって foodNames.json を src/Resources/json/以下に作成<br>
「npm run start-dev」 開発用ビルドとサーバー立ち上げ実行<br>
※各種 「npm run ~」コマンドは package.json の「scripts」にある<br>
