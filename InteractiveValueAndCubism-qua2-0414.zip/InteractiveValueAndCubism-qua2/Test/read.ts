export {};

async function main(src: string) {
    const response = await fetch(src);
    const data = await response.json();
    console.log(data);
}
main("./foodNames.json");
