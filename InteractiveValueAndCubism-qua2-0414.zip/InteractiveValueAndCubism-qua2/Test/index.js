const myLibrary = new MyLibrary();
document.addEventListener(
    "DOMContentLoaded",
    ()=> {
        console.log("DOm");
        myLibrary.onload();
    },
    false
); 

//--- cubism SDK 初期化
window.addEventListener(
    "load",
    () => {
        console.log("Win");
        myLibrary.onReady();
    },
    false
);
//-
