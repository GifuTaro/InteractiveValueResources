//アドビエント宣言をする
//・ファイル拡張子解決　declare　paths
//・型のないjsライブラリ
//などを記述する

declare module "*.png" {
    const value: any;
    export = value;
}
declare module "*.jpg" {
    const value: any;
    export = value;
}
declare module "*.gif" {
    const value: any;
    export = value;
}
declare module "*.csv" {
    const value: any;
    export = value;
}

declare module "*.json" {
    const data: any;
    export = data;
}

declare module "htmlspecialchars" {
    const value: any;
    export = value;
}

declare namespace Qualtrics {
    export namespace SurveyEngine {
        function addOnload(f: Function): any;
        function addOnReady(f: Function): any;
        function addOnUnload(f: Function): any;
    }
}
