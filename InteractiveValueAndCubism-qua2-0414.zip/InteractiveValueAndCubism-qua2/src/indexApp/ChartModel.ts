import { EventEmitter } from "./EventEmitter";
import * as Chartjs from "chart.js";
import { ChartItems, ChartItem, SectionResult, ChartUses, ObjectKeyTypes } from "./myTypes";
import * as IndexDefine from "./indexDefine";

export class ChartModel extends EventEmitter {
    public chart: Chartjs.Chart | null;
    public chartItems: ChartItems; //プロパティには、ChartItemの値がキーごとに配列で入る
    private overflows: ChartItems;
    private positiveNum: number;
    private negativeNum: number;
    public chartLength: number;
    private chartPadding: number | null;
    /**
     *
     */
    constructor() {
        super();

        this.chart = null;
        this.positiveNum = IndexDefine.PositiveNum;

        this.negativeNum = IndexDefine.NegativeNum;
        this.chartLength = IndexDefine.ChartLength;
        this.chartPadding = null;

        this.chartItems = {
            label: [],
            image: [],
            data: [],
            use: [],
            color: [],
            deleteIndex: [],
        };

        //ダミーデータ
        const marginImage = new Image();
        marginImage.src = `${IndexDefine.ResourcesPath}img/透明.png`;
        const marginData: ChartItem = {
            label: "",
            image: marginImage,
            data: 0,
            use: null,
            color: "",
            deleteIndex: null,
        };
        for (let i = 0; i < this.chartLength; i++) {
            (Object.keys(this.chartItems) as (keyof ChartItem)[]).forEach((key: keyof ChartItem): void => {
                //　　[keyはchartItems型のプロパティである]　<chartItems[key]はChartItemのキーの型を持つ配列である>　[keyはChartItems型のプロパティである]
                (this.chartItems[key] as Array<ObjectKeyTypes<ChartItem>>).push(marginData[key]);
            });
        }
        //--
        this.overflows = {
            label: [],
            image: [],
            data: [],
            use: [],
            color: [],
            deleteIndex: [],
        }; //溢れたデータを格納する
    }

    /**
     * グラフをセットする
     * @param {Chart} chart
     */
    setChart(chart: Chartjs.Chart): void {
        this.chart = chart;

        // //固定するために最初に減らす
        // for (let i = 0; i < this.chartLength; i++) {
        //     const padding: number = this.chart?.config?.options?.scales?.xAxes?.ticks?.padding as number;
        //     if (this.chart?.config?.options?.scales?.xAxes?.ticks?.padding) {
        //         this.chart.config.options.scales.xAxes.ticks.padding = padding - 16;
        //         console.log("ここ");
        //     }
        // }
        //this.chartPadding = this.chart.options.scales.xAxes[0].ticks.padding;
    }

    /**
     * 現在のパディングを設定する
     * @param{number}
     */
    /*
    setChartPadding(padding: number): void {
        this.chartPadding = padding;
    }
    */

    /**
     * TodoListの状態が更新されたときに呼び出されるリスナー関数を登録する
     * @param {Function} listener
     */
    onChange(listener: Function): void {
        this.addEventListener("change", listener);
    }

    /**
     * 状態が変更されたときに呼ぶ。登録済みのリスナー関数を呼び出す
     */
    emitChange(): void {
        this.emit("change");
    }

    /**
     * グラフを生成する
     * @param {Function} listener
     */

    onCreate(listner: Function, callback?: Function): void {
        this.addEventListener("create", listner, callback);
        //console.log("グラフcreate登録完了");
        //this.chart = this.emitCreate();//リスナー登録したら作成
        //console.log(this.chart);
    }

    /**
     * 状態が変更されたときに呼ぶ。登録済みのリスナー関数を呼び出す
     */
    emitCreate(): void {
        this.emit("create");
    }

    /**
     * TodoItemを追加する
     * @param {SectionResult} result
     */
    addData(result: SectionResult): void {
        const charData: ChartItem = {
            label: result.foodName,
            image: result.path,
            data: result.score,
            use: result.use,
            color: "#C0C0C0",
            deleteIndex: null,
        };
        if (charData.use === 1) {
            charData.color = "#ff8888";
        } else if (charData.use === -1) {
            charData.color = "#8888ff";
        }

        /**
         * イメージとしてはthis.ChartItems.push(chartItem);
         * 1.Object.keysでキー名の配列を取得
         * 2.キー名を使って繰り返す
         * 3.繰り返しの中で　chartItem[キー名].push(chartData[キー名])　ですべてンプロパティの最後尾にデータを追加
         **/
        (Object.keys(this.chartItems) as (keyof ChartItem)[]).forEach((key: keyof ChartItem): void => {
            //　　[keyはchartItems型のプロパティである]　<chartItems[key]はChartItemのキーの型を持つ配列である>　[keyはChartItems型のプロパティである]
            (this.chartItems[key] as Array<ObjectKeyTypes<ChartItem>>).push(charData[key]);
        });

        //長さが5より大きいとき時探索
        if (this.chartItems.label.length > this.chartLength) {
            console.log("探索");
            let deleteNum: number | null = null;
            let positive: number = this.positiveNum; //使う正例の数
            let negative: number = this.negativeNum; //使わない正例の数
            console.log(this.positiveNum);

            //-探索する
            //this.getBuffs("use").some((currentValue: string | number | null, currentIndex: number): unknown => {
            this.chartItems.use.some((currentValue: ChartUses, currentIndex: number) => {
                if (currentValue === 1 && positive > 0) {
                    //正例で二個以内の時
                    //buffLabels.push(this.chartLabels[currentIndex]);
                    //return true;
                    positive -= 1;
                } else if (currentValue === -1 && negative > 0) {
                    //負例で二個以内の時
                    negative -= 1;
                } else {
                    //使わないデータか、正例・負例のどちらかが二個以上見つかったとき
                    deleteNum = currentIndex; //このインデックスを削除する
                    return true;
                }
            });

            //-画像を削除する
            if (deleteNum !== null) {
                console.log(`消した食べ物は${this.chartItems.label[deleteNum]}`);
                this.chartItems.deleteIndex[deleteNum] = deleteNum;
                //this.overflows.push(this.ChartItems[deleteIndex]); //消したバッファーに追加
                (Object.keys(this.chartItems) as (keyof ChartItem)[]).forEach((key: keyof ChartItem): void => {
                    //                                                                            push(オブジェクト  [      キー名          ][    消す番号       ])
                    (this.overflows[key] as Array<ObjectKeyTypes<ChartItem>>).push(this.chartItems[key][deleteNum as number]);
                });

                //this.ChartItems.splice(deleteIndex, 1);//元のデータから削除
                (Object.keys(this.chartItems) as (keyof ChartItem)[]).forEach((key: keyof ChartItem): void => {
                    (this.chartItems[key] as Array<ObjectKeyTypes<ChartItem>>).splice(deleteNum as number, 1);
                });
            }

            //
        }
        console.log("グラフの状態");
        console.log(this.chartItems);
        console.log(this.overflows);

        this.emitChange();
    }
    /**
     * TodoItemを追加する
     * @param {SectionResult} result
     */
    deleteData(): void {
        //一つもデータ溢れていなかったら
        if (this.overflows.label.length === 0) {
            //this.ChartItems.pop(); //最後の列をuseにかかわらず消す(入力しなおすから)
            (Object.keys(this.chartItems) as (keyof ChartItem)[]).forEach((key: keyof ChartItem): void => {
                (this.chartItems[key] as Array<ObjectKeyTypes<ChartItem>>).pop();
            });
        }
        //データが溢れていたら
        else {
            //this.chartItems.pop(); //最後の列をuseにかかわらず消す(入力しなおすから)
            (Object.keys(this.chartItems) as (keyof ChartItem)[]).forEach((key: keyof ChartItem): void => {
                (this.chartItems[key] as Array<ObjectKeyTypes<ChartItem>>).pop();
            });

            //const undoBuff = this.overflows.pop() as ChartItem; //最後尾を消して代入
            let undoBuff: ChartItem = {
                label: "",
                image: new Image(),
                data: 0,
                use: 0,
                color: "#C0C0C0",
                deleteIndex: null,
            };
            (Object.keys(this.chartItems) as (keyof ChartItem)[]).forEach((key: keyof ChartItem): void => {
                let tmp = (this.overflows[key] as Array<ObjectKeyTypes<ChartItem>>).pop() as ObjectKeyTypes<ChartItem>;
                (undoBuff[key] as ObjectKeyTypes<ChartItem>) = tmp;
            });

            const deleteIndex = undoBuff.deleteIndex as number;

            //apply<T, A extends any[], R>(this: (this: T, ...args: A) => R, thisArg: T, args: A): R;
            //より「args: A」でapplyが特定の型の配列を受け取れるよう型引数に代入する
            //Array.prototype.splice.apply<any, any[], (number | ChartItem)[]>(this.chartItems, tmp); //消したところに代入
            (Object.keys(this.chartItems) as (keyof ChartItem)[]).forEach((key: keyof ChartItem): void => {
                //-(number|ChartItem)[]で複数の型のの配列であることを宣言
                const tmp: (ObjectKeyTypes<ChartItem> | number)[] = ([deleteIndex, 0] as (number | ObjectKeyTypes<ChartItem>)[]).concat(undoBuff[key]);
                Array.prototype.splice.apply(this.chartItems[key as keyof ChartItems], tmp);
                //Array.prototype.splice.apply<any, any[], (string | number | null)[]>(this.chartItems[key as keyof ChartItems], tmp);
            });

            console.log(`戻した食べ物は${undoBuff?.label}`);
        }
        console.log("グラフの状態");
        console.log(this.chartItems);
        console.log(this.overflows);

        this.emitChange();
    }

    createRender(): Chartjs.Chart {
        console.log("グラフ作成"); //-------------------ー－－－－－－－－－－－－－－－－－－ここがあるとグラフの出力が安定
        const ctx = document.getElementById("myChart") as HTMLCanvasElement;
        console.log(ctx);
        //-グラフのプラグイン
        /*
        function handleBeforeDraw(chartModel: ChartModel) {
            //引数にthisではないchartModelをおいておく※this.chartModelはonCreateないでプラグインを登録するときに渡す
            return function (chart: Chartjs.Chart, args: { cancelable: true }, options: Record<string, unknown>): void {
                const images = chartModel.chartItems["image"];
                const ctx: CanvasRenderingContext2D = chart.ctx; //canvas取得
                const xAxis: Chartjs.Scale<Chartjs.CoreScaleOptions> = chart.scales.xAxes; //x軸全体を取得
                const yAxis: Chartjs.Scale<Chartjs.CoreScaleOptions> = chart.scales.yAxes; //y軸全体を取得
                const xPadding = chart?.options?.scales?.xAxes?.ticks?.padding as number;
                let width: number = ((xAxis.width / (xAxis.ticks.length + 1)) * 2) / 3;
                //-画像の大きさは最大180 paddingが二百なので
                if (width > xPadding * 0.9) {
                    width = 180;
                }
                //
                //console.log(chart.options.scales.xAxes[0].ticks.padding);
                //this.chartModel.setPadding(width*1.5);
                //console.log(chart);
                xAxis.ticks.forEach((value, index) => {
                    //x軸のメモリごとにメモリのテキスト=value・何番目か=indexを取得
                    const x: number = xAxis.getPixelForTick(index); //indexから指定された値のcanvas上のピクセル(横軸のX座標、縦軸のX座標)を取得します。
                    const image: HTMLImageElement = new Image();
                    try {
                        image.src = images[index];
                    } catch (error) {
                        console.log(error);
                        console.log("グラフの画像がないです");
                    }
                    ctx.drawImage(image, x - width / 2, yAxis.bottom + (xPadding / 2 - width / 2), width, width); //メモリ下部中心からx軸方向に-12px,
                });

                const height: number = yAxis.height / (yAxis.ticks.length - 1);
                const left: number = xAxis.left; //getPixelForValue();  // 塗りつぶしを開始するラベル位置
                const right: number = xAxis.right; //getPixelForValue(1988); // 塗りつぶしを終了するラベル位置
                //-下部を塗る
                let top: number = yAxis.getPixelForTick(1); // 塗りつぶしの基点（二行目の左下端）
                // 塗りつぶしの基点（上端）
                // 塗りつぶす長方形の設定
                ctx.fillStyle = "rgba(0, 0, 255, 0.2)";
                ctx.fillRect(left, top, right - left, height);
                //

                //-上部を塗る

                top = yAxis.getPixelForTick(yAxis.ticks.length - 1);
                // 塗りつぶす長方形の設定
                ctx.fillStyle = "rgba(255, 0, 0, 0.2)";
                ctx.fillRect(left, top, right - left, height);
                //
            };
        }
        */

        function handleAfterDraw(chartModel: ChartModel) {
            //引数にthisではないchartModelをおいておく※this.chartModelはonCreateないでプラグインを登録するときに渡す
            return function (chart: Chartjs.Chart, args: Record<string, never>, options: Record<string, unknown>): void {
                const images = chartModel.chartItems["image"];
                const ctx: CanvasRenderingContext2D = chart.ctx; //canvas取得
                const xAxis: Chartjs.Scale<Chartjs.CoreScaleOptions> = chart.scales.xAxes; //x軸全体を取得
                const yAxis: Chartjs.Scale<Chartjs.CoreScaleOptions> = chart.scales.yAxes; //y軸全体を取得
                const xPadding = chart?.options?.scales?.xAxes?.ticks?.padding as number;
                let width: number = ((xAxis.width / (xAxis.ticks.length + 1)) * 2) / 3;
                //-画像の大きさは最大180 paddingが二百なので
                if (width > xPadding) {
                    width = xPadding * 0.8;
                }
                //
                //console.log(chart.options.scales.xAxes[0].ticks.padding);
                //this.chartModel.setPadding(width*1.5);
                //console.log(chart);
                xAxis.ticks.forEach((value, index) => {
                    //x軸のメモリごとにメモリのテキスト=value・何番目か=indexを取得
                    const x: number = xAxis.getPixelForTick(index); //indexから指定された値のcanvas上のピクセル(横軸のX座標、縦軸のX座標)を取得します。
                    const image: HTMLImageElement = images[index];
                    // try {
                    //     image.src = ;
                    // } catch (error) {
                    //     console.log(error);
                    //     console.log("グラフの画像がないです");
                    // }
                    /*
                    //イメージロード後に描画する　ちらつき防止
                    image.addEventListener("load", (event: Event) => {
                        // 画像を何かする。背景としてCSSで設定するとか。
                        const image = event.target as HTMLImageElement;
                        ctx.drawImage(image, x - width / 2, yAxis.bottom + (xPadding / 2 - width / 2), width, width); //メモリ下部中心からx軸方向に-12px,
                    });
                    */
                    //console.log(image);
                    ctx.drawImage(image, x - width / 2, yAxis.bottom + (xPadding / 2 - width / 2), width, width); //メモリ下部中心からx軸方向に-12px,
                });
            };
        }

        function handleBeforeDraw() {
            return function (chart: Chartjs.Chart, args: { cancelable: true }, options: Record<string, unknown>) {
                // 範囲を設定
                const ctx: CanvasRenderingContext2D = chart.ctx; //canvas取得
                const xAxis: Chartjs.Scale<Chartjs.CoreScaleOptions> = chart.scales.xAxes;
                const yAxis: Chartjs.Scale<Chartjs.CoreScaleOptions> = chart.scales.yAxes;
                const height: number = yAxis.height / (yAxis.ticks.length - 1);
                const left: number = xAxis.left; //getPixelForValue();  // 塗りつぶしを開始するラベル位置
                const right: number = xAxis.right; //getPixelForValue(1988); // 塗りつぶしを終了するラベル位置

                //-下部を塗る
                let top: number = yAxis.getPixelForTick(1); // 塗りつぶしの基点（二行目の左下端）
                // 塗りつぶしの基点（上端）
                // 塗りつぶす長方形の設定
                ctx.fillStyle = "rgba(0, 0, 255, 0.2)";
                ctx.fillRect(left, top, right - left, height);
                //

                //-上部を塗る

                top = yAxis.getPixelForTick(yAxis.ticks.length - 1);
                // 塗りつぶす長方形の設定
                ctx.fillStyle = "rgba(255, 0, 0, 0.2)";
                ctx.fillRect(left, top, right - left, height);
                //
            };
        }
        //

        //-グラフの初期設定
        const chartConfig: Chartjs.ChartConfiguration = {
            plugins: [
                {
                    id: "bar",
                    //beforeDraw: handleBeforeDraw(this),

                    afterDraw: handleAfterDraw(this),
                    beforeDraw: handleBeforeDraw(),
                },
            ],

            type: "bar",
            data: {
                labels: this.chartItems["label"], //referSame(this.chartModel,"label")(),//クロージャー使えない、関数を登録しているのではなく値を登録しているため、最後に()で呼び出す必要がある//[this.sectionModel.sectionItems[0].foodName],//モデルのラベルを参照する
                datasets: [
                    {
                        label: "", //"パクチーイリフォー",
                        data: this.chartItems["data"], //referSame(this.chartModel,"data")(),//モデルの値を参照する
                        backgroundColor: this.chartItems["color"], //'#f88',
                    },
                ],
            },
            options: {
                //responsive: false,
                //maintainAspectRatio: false,
                scales: {
                    yAxes:
                        // Ｙ軸
                        {
                            // 目盛り
                            suggestedMin: 0, //最小値
                            suggestedMax: 100, // 最大値

                            //beginAtZero: true,
                            ticks: {
                                // beginAtZero: true でも同じ
                                stepSize: 10, // 間隔
                            },
                        },
                    xAxes: {
                        ticks: {
                            padding: 120, //200, //x軸において設定するとy軸方向に適用される
                            font: {
                                size: 14,
                                weight: "bold",
                            },
                        },
                    },
                },

                plugins: {
                    legend: {
                        // 凡例の非表示
                        display: false,
                    },
                },

                animation: {
                    duration: 500,
                },
            },
        };

        //Chartの形を登録しないと使えない
        Chartjs.Chart.register(...Chartjs.registerables);
        const chart = new Chartjs.Chart(ctx, chartConfig);
        //ロードされないときのための対策
        setTimeout(() => {
            chart.update();
            console.log("グラフ更新実行");
        }, 1000);
        return chart;
    }

    changeRender(): void {
        //xPaddingをデータの数に合わせてうまいこと調整
        //プロパティが存在し、二つ以上のデータを表示しており、最大描画数に達していないなら
        // if (this.chart?.config?.options?.scales?.xAxes?.ticks && this.chart.config.data.datasets[0].data.length >= 2 && this.chart.config.data.datasets[0].data.length < IndexDefine.ChartLength) {
        //     const padding: number = this.chart?.config?.options?.scales?.xAxes?.ticks?.padding as number;
        //     this.chart.config.options.scales.xAxes.ticks.padding = padding - 16;
        // }
        //-

        //chart更新
        this.chart?.update();
        //console.log(this.chartModel.chart);
    }
}
