import { SectionItem } from "./myTypes";
import { EventEmitter } from "./EventEmitter";
import { LAppDelegate } from "../cubism/lappdelegate";
import { LAppLive2DManager } from "../cubism/lapplive2dmanager";
import * as htmlspecialchars from "htmlspecialchars";
import * as IndexDefine from "./indexDefine";
import { builtinModules } from "module";
export class BubbleModel extends EventEmitter {
    public intervalId: NodeJS.Timer | null;
    public sectionItem: SectionItem | null;

    //public sectionModel: SectionModel;

    constructor() {
        super();

        this.intervalId = null;
        this.sectionItem = null;
    }

    /**
     * 吹き出しを生成する
     * @param {Function} listener
     */
    onCreate(listner: Function): void {
        this.addEventListener("create", listner);
    }

    /**
     * 状態が変更されたときに呼ぶ。登録済みのリスナー関数を呼び出す
     */
    emitCreate(): void {
        this.emit("create");
    }
    /**
     * 吹き出しを生成する
     * @param {Function} listener
     */
    onChange(listner: Function, callcack?: Function): void {
        this.addEventListener("change", listner, callcack);
    }

    /**
     * 状態が変更されたときに呼ぶ。登録済みのリスナー関数を呼び出す
     */
    emitChange(): void {
        this.emit("change");
    }

    /**
     * 吹き出しを生成する
     * @param {Function} listener
     */
    onComplete(listner: Function): void {
        this.addEventListener("complete", listner);
    }

    /**
     * 状態が変更されたときに呼ぶ。登録済みのリスナー関数を呼び出す
     */
    emitComplete(): void {
        this.emit("complete");
    }

    setId(intervalId: NodeJS.Timer): void {
        this.intervalId = intervalId;
        //console.log("コールバックが呼ばれました");
    }
    clearId(): void {
        if (this.intervalId != null) {
            LAppDelegate.getInstance().onSpeakStop(); //話すすのをやめさせる
            clearInterval(this.intervalId);
            this.intervalId = null;
        }
    }

    changeBubble(sectionItem: SectionItem): void {
        this.sectionItem = sectionItem;
        this.clearId();
        this.emitChange();
    }
    completeBubble(): void {
        this.clearId();
        this.emitComplete();
    }

    changeRender(): NodeJS.Timer {
        const bubbleText = document.getElementById("bubbleText") as HTMLElement;
        const foodFrame = document.getElementById("foodFrame") as HTMLElement;
        const foodImg = document.getElementById("foodImg") as HTMLImageElement;
        const foodText = document.getElementById("foodText") as HTMLElement;
        const foodName: string = this.sectionItem?.foodName as string;
        const replaceImg: HTMLImageElement = this.sectionItem?.path as HTMLImageElement;

        //-吹き出し作成
        let n: number = 1; //文字を増やす処理の回数を数える変数nの宣言//n = 1; //nの初期値を1とする
        const text: string = `${foodName}は好きですか?`;
        const len = text.length; //入力された文字の変数sの文字数をカウントする変数lenの宣言
        //↓関数の宣言↓
        const intervalId = setInterval(() => {
            //もししゃべり始めてないようなら始めさせる
            if (LAppLive2DManager.getInstance()?.isSpeakings()[0] === false) {
                LAppDelegate.getInstance().onSpeakStart();
            }

            //console.log(text);
            //htmlspecialcharsでエスケープする
            bubbleText.innerHTML = this.makeSpace(text, n); //HTMLのoutput_spaceというidの要素に、変数sの０文字目からn文字までのテキストを表示する
            if (n < len) {
                //文字を増やす処理の回数が入力された文字数を超えるまで繰り返す
                n++;
            } else {
                //文字を増やす処理の回数が入力された文字数を超えた時の処理
                //LAppDelegate.getInstance().onSpeakStop();
                this.clearId(); //clearInterval(intervalId as NodeJS.Timer); //タイマーをリセットする
                //text = null; //変数sを空にする
            }
        }, 180); //2000ミリ秒(2.0秒)ごとにword()関数の処理を実行する

        //画像を事前に読み込んでいたものに入れ替える
        replaceImg.id = foodImg.id;
        replaceImg.className = foodImg.className;
        foodImg.remove();
        foodFrame.insertBefore(replaceImg, foodFrame.firstChild);
        //----

        // try {
        //     foodImg.src = foodSrc;
        // } catch (error) {
        //     console.log(error);
        //     console.log("画像がないです");
        // }
        foodText.innerText = foodName;

        return intervalId; //setIdに渡す引数
    }

    createRender() {
        const bubbleText = document.getElementById("bubbleText") as HTMLElement;
        const foodImg = document.getElementById("foodImg") as HTMLImageElement;
        const foodText = document.getElementById("foodText") as HTMLElement;
        bubbleText.innerText = "下の「次に進む」ボタンで始まります";
        foodText.innerText = "上に食べ物の画像が表示されます";
        foodImg.src = `${IndexDefine.ResourcesPath}/img/Live2DLogo.png`;
        console.log("クリエイトバブル"); //-----------------------------------------------------ここがあるとバブルの出力が安定
        console.log(bubbleText);
        console.log(foodImg);
        console.log(foodText);
    }

    completeRender() {
        const bubbleText = document.getElementById("bubbleText") as HTMLElement;
        const foodFrame = document.getElementById("foodFrame") as HTMLElement;
        const foodImg = document.getElementById("foodImg") as HTMLImageElement;
        const foodText = document.getElementById("foodText") as HTMLElement;
        bubbleText.innerText = "※確定ボタンで次の質問ページに進んでください";
        const replaceImg = new Image();
        replaceImg.id = foodImg.id;
        replaceImg.className = foodImg.className;
        replaceImg.src = `${IndexDefine.ResourcesPath}img/Live2DLogo.png`;
        foodImg.remove();
        foodFrame.insertBefore(replaceImg, foodFrame.firstChild);

        foodText.innerText = "※この質問は終了です";

        //this.emitComplete();
    }

    makeSpace(text: string, n: number): string {
        const length = text.length - n;
        let space: string = "";
        // if (length !== 0) {
        //     //1.半角スペース+nbsp で全角一文字　 style="white-space: pre-wrap"必須
        //     space = space.concat("\u0020"); //改行可能半角スペース
        //     space = space.concat("&nbsp;"); //改行不可半角スペース　space = space.concat("&emsp;");

        //     //2.もしくは
        //     //space = space.concat(" &nbsp;");//"半角スペース+$nbsp"で全角一文字の空白が作れる。
        // }
        for (let i: number = 0; i < length; i++) {
            space = space.concat("\u0020");
            space = space.concat("&ensp;"); //space = space.concat("&emsp;");
        }
        // if (length !== 0) {
        //     //1.半角スペース+nbsp で全角一文字　 style="white-space: pre-wrap"必須
        //     space = space.concat("&ensp;"); //半角スペースより少し広い
        //     space = space.concat("&nbsp;"); //改行不可半角スペース　space = space.concat("&emsp;");

        //     //2.もしくは
        //     //space = space.concat(" &nbsp;");//"半角スペース+$nbsp"で全角一文字の空白が作れる。
        // }

        return htmlspecialchars(text.slice(0, n)).concat(space);
    }
}
