import { EventEmitter } from "./EventEmitter";
//import { SectionItem } from "./SectionItem.js";
import { ChartModel } from "./ChartModel";
import { BubbleModel } from "./BubbleModel";
import { SectionItem, SectionResult, SectionState, ObjectKeyTypes, FinalResult } from "./myTypes";
import { LAppDelegate } from "../cubism/lappdelegate";
import * as IndexDefine from "./indexDefine";

export class SectionModel extends EventEmitter {
    public state: ObjectKeyTypes<typeof SectionState>; //constなのでキーの値のリテラルの合併型になる
    public sectionItems: SectionItem[];
    private sectionMax: number | null;
    public sectionNum: number | null;
    public sectionResults: SectionResult[];
    //public readonly useResults: [];
    private positiveNum: number;
    private negativeNum: number;
    private chartModel: ChartModel;
    public usePositives: SectionResult[];
    public useNegatives: SectionResult[];
    public finalResults: FinalResult[];
    public bubbleModel: BubbleModel;

    /**
     * @param {BubbleModel} bubblemodel バブルモデル
     * @param {ChartModel} チャートモデル
     * @param {number} positiveNum 正例の数
     * @param {number} negativeNum 負例の数
     *
     *
     */
    constructor(bubbleModel: BubbleModel, chartModel: ChartModel) {
        super();
        this.state = SectionState.NoLoaded;

        this.sectionItems = [];
        this.sectionMax = null; //食べ物の数
        this.sectionNum = null;

        this.sectionResults = [];
        //this.useResults = [];
        this.positiveNum = IndexDefine.PositiveNum;
        this.negativeNum = IndexDefine.NegativeNum;
        this.usePositives = [];
        this.useNegatives = [];
        this.finalResults = [];

        this.chartModel = chartModel;
        this.bubbleModel = bubbleModel;
        this.setItems();
    }

    /**
     * Csvに格納されているデータを二次元配列のStringで返す
     * @returns {String[][]}
     */
    async setItems(): Promise<void> {
        //-csv読み込み
        let dataArray: string[] = await fetch(`${IndexDefine.ResourcesPath}json/foodNames.json`)
            .then((response: Response) => {
                if (response.ok) {
                    console.log(`JSON読み込み成功${response.status}`); // => 200
                    this.state = SectionState.CompleteLoad; //ここでファイルが読み込めて操作を受け付けるかどうかを示せる
                }
                return response.json();
            })
            .catch((error: Error) => {
                console.log(error);
            });
        //

        /*
        //-csvを配列に加工
        const dataArray: string[][] = []; //二次元配列を用意
        const dataString: string[] = (data as string)?.split("\r\n") as string[]; //改行で分割
        for (let i = 1; i < dataString.length; i++) {
            //あるだけループ//一行目はコラムなので無視
            const tmp: string[] = dataString[i].split(","); //,つまり列で分割
            if (tmp[0] !== "") {
                //一行目が空白の物は入れない
                dataArray.push(tmp);
            }
        }
        //
        */

        //-配列からデータを格納する
        let idNum: number = 0;
        console.log(dataArray);
        dataArray = this.shuffle(dataArray);
        dataArray.forEach((currentValue: string): void => {
            const prefix: number = currentValue.search(/^\d{4}_/) + 5;
            const extention: number = currentValue.search(/\.(eot|svg|ttf|woff|woff2|png|jpg|gif)$/);
            const foodName: string = currentValue.slice(prefix, extention);
            const foodImage: HTMLImageElement = new Image();
            foodImage.src = `${IndexDefine.ResourcesPath}foodImgs/${currentValue}`;
            this.sectionItems.push({
                id: idNum,
                foodName: foodName,
                path: foodImage,
            });
            idNum += 1;
        });
        //

        console.log("モデルに格納されているデータ一覧↓");
        console.log(this.sectionItems);
        this.sectionMax = this.sectionItems.length - 1; //取得したデータの数-1を登録
        this.sectionNum = 0;

        //this.emitChange();

        this.state = SectionState.Staying; //最初の待機中である
        this.bubbleModel.emitCreate(); //吹き出し表示
        this.chartModel.emitCreate(); //グラフを作成する

        console.log("!----");
        console.log(`このセクションは${this.sectionNum}番目`);
    }

    shuffle<T>(array: Array<T>): Array<T> {
        for (let i = array.length - 1; i >= 0; i--) {
            let rand = Math.floor(Math.random() * (i + 1));
            // 配列の数値を入れ替える
            [array[i], array[rand]] = [array[rand], array[i]];
        }
        return array;
    }
    /*
    importPaths(path: string) {
        return import(path).then;
    }
    */

    /**
     * セクション全体を返す
     * @returns {number}
     */
    getSectionItems(): SectionItem[] {
        return this.sectionItems;
    }
    /**
     * 現在のセクションを返す
     * @returns {number}
     */
    getSectionNum(): number | null {
        return this.sectionNum;
    }

    /**
     * 現在のセクションの中身を返す
     * @returns {number}
     */
    getCurrentContent(): SectionItem {
        return this.sectionItems[this.sectionNum as number];
    }

    /**
     * TodoListの状態が更新されたときに呼び出されるリスナー関数を登録する
     * @param {Function} listener
     */
    /*
    onChange(listener: Function): void {
        this.addEventListener("change", listener);
    }
    */

    /**
     * 状態が変更されたときに呼ぶ。登録済みのリスナー関数を呼び出す
     */
    /*
    emitChange(): void {
        this.emit("change");
    }
    */

    /**
     * アンケートが完了＝既定のデータ数に達したときに呼び出されるリスナー関数を登録する
     * @param {Function} listener
     */
    onComplete(listener: Function) {
        this.addEventListener("complete", listener);
    }

    /**
     * アンケートが完了ときに呼ぶ。登録済みのリスナー関数を呼び出す
     */
    emitComplete() {
        this.emit("complete");
    }

    /**
     * アンケートが完了＝既定のデータ数に達したときに呼び出されるリスナー関数を登録する
     * @param {Function} listener
     */
    onLack(listener: Function) {
        this.addEventListener("lack", listener);
    }

    /**
     * アンケートが完了ときに呼ぶ。登録済みのリスナー関数を呼び出す
     */
    emitLack() {
        this.emit("lack");
    }

    sectionStart() {
        this.state = SectionState.ModelIlde;
        this.bubbleModel.changeBubble(this.getCurrentContent());
        LAppDelegate.getInstance().onSpeakStart();
    }

    /**
     * SectionResultを追加する
     * @param {SectionResult} result
     */
    sectionNext(result: SectionResult): void {
        console.log("!----");

        this.sectionResults.push(result);
        if (result.use === 1 && this.usePositives.length < this.positiveNum) {
            this.usePositives.push(result);
        } else if (result.use === -1 && this.useNegatives.length < this.negativeNum) {
            this.useNegatives.push(result);
        }

        const buffs = this.usePositives.concat(this.useNegatives);
        //this.finalResults = buffs;

        console.log("結果全体");
        console.log(this.sectionResults);
        console.log("使う結果");
        console.log(buffs);
        if (this.sectionNum != null) {
            this.sectionNum += 1;
        }

        //-終了判定 // 使う結果が集めるデータと等しいとき
        if (buffs.length === this.positiveNum + this.negativeNum) {
            //最終結果を作成
            const finalResults: FinalResult[] = buffs.map((currentValue: SectionResult) => {
                return {
                    id: currentValue.id,
                    foodName: currentValue.foodName,
                    path: currentValue.path.src,
                    score: currentValue.score,
                    use: currentValue.use,
                };
            });
            this.finalResults = finalResults;
            console.log("最終結果");
            console.log(finalResults);

            this.state = SectionState.ItemCollected; //外部からの追加無効か
            this.chartModel.addData(result); //グラフ更新
            this.bubbleModel.completeBubble(); //吹き出し更新

            //-グラフが表示されきるまでタイムラグあるので何秒か待機
            setTimeout(() => {
                console.log(`${this.positiveNum + this.negativeNum}個のアイテム収集完了`);
                this.emitComplete();
            }, 2000);
            //
        } else {
            //-次回の用意
            //this.emitChange();
            this.bubbleModel.changeBubble(this.getCurrentContent());
            this.chartModel.addData(result); //グラフ更新
            LAppDelegate.getInstance().onSpeakStart();

            console.log(`このセクションは${this.sectionNum}番目`);
        }
        //

        //アイテム数が足りているか判定
        if (this.sectionNum === this.sectionMax) {
            //エラー用に到達したとき
            this.state = SectionState.ItemLack;
            console.log("数が足りません");
            //-グラフが表示されきるまでタイムラグあるので何秒か待機
            setTimeout(() => {
                this.emitLack(); //ここでエラー表示をしている
            }, 2000);
        }
        //
    }

    /**
     * SectionResultを削除する
     * @param {SectionResult} result
     */
    sectionBack(): void {
        console.log("----!");
        if (this.state === SectionState.ItemCollected || this.state === SectionState.ItemLack) {
            //データが集まりきっているかデータが足りないなら
            this.state = SectionState.ModelIlde; //集まっていないとする
        }

        /*
        if (this.itemLack === true) {
            //データが足りないなら
            this.itemLack = false; //足りているとする
        }
        */

        if (this.usePositives[this.usePositives.length - 1] === this.sectionResults[this.sectionResults.length - 1]) {
            this.usePositives.pop();
        } else if (this.useNegatives[this.useNegatives.length - 1] === this.sectionResults[this.sectionResults.length - 1]) {
            this.useNegatives.pop();
        }
        this.sectionResults.pop();

        const buffs = this.usePositives.concat(this.useNegatives);
        //this.finalResults = buffs;

        console.log("結果全体");
        console.log(this.sectionResults);
        console.log("使う結果");
        console.log(buffs);
        //-次回の用意
        if (this.sectionNum != null) {
            this.sectionNum -= 1;
        }

        this.chartModel.deleteData(); //グラフ更新
        this.bubbleModel.changeBubble(this.getCurrentContent());
        LAppDelegate.getInstance().onSpeakStart();
        //this.emitChange();

        console.log(`このセクションは${this.sectionNum}番目`);
    }

    finidhRender(): void {
        const message = this.finalResults.reduce((accumulator, currentValue) => {
            return accumulator + `食べ物：${currentValue.foodName}、スコア：${currentValue.score}\n`;
        }, `結果は\n`);
        console.log(this.finalResults);
        alert(message);
    }

    lackRender() {
        const message = "アンケート収集用の食べ物の数が足りません。";
        console.log(this.finalResults);
        alert(message);
    }
}
