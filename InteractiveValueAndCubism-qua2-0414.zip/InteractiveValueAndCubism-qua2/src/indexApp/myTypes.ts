export type SectionItem = {
    id: number;
    foodName: string;
    path: HTMLImageElement;
};

export type ChartUses = -1 | 0 | 1 | null;
export type ChartColors = "#C0C0C0" | "#ff8888" | "#8888ff" | "";
//type ChartSrc<P> = `${P}${string}`;

export type SectionResult = SectionItem & {
    score: number;
    use: ChartUses;
};
export type FinalResult = {
    id: number;
    foodName: string;
    path: string;
    score: number;
    use: ChartUses;
};

export type ChartItem = {
    label: string;
    image: HTMLImageElement;
    data: number;
    use: ChartUses;
    color: ChartColors;
    deleteIndex: number | null;
};

export type ChartItems = ArrayingObject<ChartItem>;
/*ChartItemsのイメージ
type ChartItems = {
    label: string[];
    image: string[];
    data: number[];
    use: CharUses[];
    color: ChartColors[];
    deleteIndex: number[];
};
*/

//オブジェクトのキーの型を合併型として取り出す型関数、オブジェクトのキーの型を求められる時に使う
export type ObjectKeyTypes<T extends object> = T extends { [U in keyof T]: infer R } ? R : never;

//オブジェクトを同じキーを持ち、キーの型を配列にする型関数
export type ArrayingObject<T> = {
    [U in keyof T]: T[U][];
};

//SectionModelの状態
export const SectionState = {
    NoLoaded: 0,
    CompleteLoad: 1,
    Staying: 2,
    ModelIlde: 3,
    ItemLack: 4,
    ItemCollected: 5,
} as const;
/*
//enum非推奨　https://qiita.com/saba_can00/items/696baa5337eb10c37342
//https://www.kabuku.co.jp/developers/good-bye-typescript-enum
//https://engineering.linecorp.com/ja/blog/typescript-enum-tree-shaking/
export enum SectionState {
    NoLoaded,
    CompleteLoad,
    Staying,
    ModelIlde,
    ItemLack,
    ItemCollected,
}

//配列を用いたunion型の生成　https://www.kabuku.co.jp/developers/good-bye-typescript-enum#:~:text=const%20permissions%20%3D%20%5B%27read%27%2C%20%27write%27%2C%20%27execute%27%5D%20as%20const%3B%0Atype%20Permission%20%3D%20typeof%20permissions%5Bnumber%5D%3B%20//%20%27read%27%20%7C%20%27write%27%20%7C%20%27execute%27
const permissions = ['read', 'write', 'execute'] as const;
type Permission = typeof permissions[number]; // 'read' | 'write' | 'execute'
*/
