/**
 * Copyright(c) Live2D Inc. All rights reserved.
 *
 * Use of this source code is governed by the Live2D Open Software license
 * that can be found at https://www.live2d.com/eula/live2d-open-software-license-agreement_en.html.
 */

import { canvas, gl } from "./lappdelegate";

/**
 * スプライトを実装するクラス=固定画像するクラス
 *
 * テクスチャＩＤ、Rectの管理
 *
 * XYは中心座標?
 */
export class LAppSprite {
    _texture: WebGLTexture | null; // テクスチャ
    _vertexBuffer: WebGLBuffer | null; // 頂点バッファ
    _uvBuffer: WebGLBuffer | null; // uv頂点バッファ
    _indexBuffer: WebGLBuffer | null; // 頂点インデックスバッファ
    _rect: Rect | null; // 矩形

    _positionLocation: number | null;
    _uvLocation: number | null;
    _textureLocation: WebGLUniformLocation | null;

    _positionArray: Float32Array | null;
    _uvArray: Float32Array | null;
    _indexArray: Uint16Array | null;

    _firstDraw: boolean;
    /**
     * コンストラクタ
     * @param x            x座標
     * @param y            y座標
     * @param width        横幅
     * @param height       高さ
     * @param textureId    テクスチャ
     */
    constructor(x: number, y: number, width: number, height: number, textureId: WebGLTexture) {
        this._rect = new Rect();
        this._rect.left = x - width * 0.5;
        this._rect.right = x + width * 0.5;
        this._rect.up = y + height * 0.5;
        this._rect.down = y - height * 0.5;
        this._texture = textureId;
        this._vertexBuffer = null;
        this._uvBuffer = null;
        this._indexBuffer = null;

        this._positionLocation = null;
        this._uvLocation = null;
        this._textureLocation = null;

        this._positionArray = null;
        this._uvArray = null;
        this._indexArray = null;

        this._firstDraw = true;
    }

    /**
     * 解放する。
     */
    public release(): void {
        this._rect = null;

        gl?.deleteTexture(this._texture);
        this._texture = null;

        gl?.deleteBuffer(this._uvBuffer);
        this._uvBuffer = null;

        gl?.deleteBuffer(this._vertexBuffer);
        this._vertexBuffer = null;

        gl?.deleteBuffer(this._indexBuffer);
        this._indexBuffer = null;
    }

    /**
     * テクスチャを返す
     */
    public getTexture(): WebGLTexture {
        return this._texture as WebGLTexture;
    }

    /**
     * 描画する。
     * @param programId シェーダープログラム
     * @param canvas 描画するキャンパス情報
     */
    public render(programId: WebGLProgram): void {
        if (this._texture == null) {
            // ロードが完了していない
            return;
        }

        // 初回描画時
        if (this._firstDraw) {
            if (gl) {
                // 何番目のattribute変数か取得
                this._positionLocation = gl.getAttribLocation(programId, "position");
                gl.enableVertexAttribArray(this._positionLocation);

                this._uvLocation = gl.getAttribLocation(programId, "uv");
                gl.enableVertexAttribArray(this._uvLocation);

                // 何番目のuniform変数か取得
                this._textureLocation = gl.getUniformLocation(programId, "texture");

                // uniform属性の登録
                gl.uniform1i(this._textureLocation, 0);

                // uvバッファ、座標初期化
                {
                    this._uvArray = new Float32Array([1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0]);

                    // uvバッファを作成
                    this._uvBuffer = gl.createBuffer();
                }

                // 頂点バッファ、座標初期化
                {
                    if (canvas && this._rect) {
                        const maxWidth = canvas.width;
                        const maxHeight = canvas.height;

                        // 頂点データ
                        this._positionArray = new Float32Array([
                            ((this._rect.right as number) - maxWidth * 0.5) / (maxWidth * 0.5),
                            ((this._rect.up as number) - maxHeight * 0.5) / (maxHeight * 0.5),
                            ((this._rect.left as number) - maxWidth * 0.5) / (maxWidth * 0.5),
                            ((this._rect.up as number) - maxHeight * 0.5) / (maxHeight * 0.5),
                            ((this._rect.left as number) - maxWidth * 0.5) / (maxWidth * 0.5),
                            ((this._rect.down as number) - maxHeight * 0.5) / (maxHeight * 0.5),
                            ((this._rect.right as number) - maxWidth * 0.5) / (maxWidth * 0.5),
                            ((this._rect.down as number) - maxHeight * 0.5) / (maxHeight * 0.5),
                        ]);
                    }

                    // 頂点バッファを作成
                    this._vertexBuffer = gl.createBuffer();
                }

                // 頂点インデックスバッファ、初期化
                {
                    // インデックスデータ
                    this._indexArray = new Uint16Array([0, 1, 2, 3, 2, 0]);

                    // インデックスバッファを作成
                    this._indexBuffer = gl.createBuffer();
                }

                this._firstDraw = false;
            }
        }
        if (gl) {
            // UV座標登録
            gl.bindBuffer(gl.ARRAY_BUFFER, this._uvBuffer);
            gl.bufferData(gl.ARRAY_BUFFER, this._uvArray, gl.STATIC_DRAW);

            // attribute属性を登録
            gl.vertexAttribPointer(this._uvLocation as number, 2, gl.FLOAT, false, 0, 0);

            // 頂点座標を登録
            gl.bindBuffer(gl.ARRAY_BUFFER, this._vertexBuffer);
            gl.bufferData(gl.ARRAY_BUFFER, this._positionArray, gl.STATIC_DRAW);

            // attribute属性を登録
            gl.vertexAttribPointer(this._positionLocation as number, 2, gl.FLOAT, false, 0, 0);

            // 頂点インデックスを作成
            gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this._indexBuffer);
            gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, this._indexArray, gl.DYNAMIC_DRAW);

            // モデルの描画
            gl.bindTexture(gl.TEXTURE_2D, this._texture);
            gl.drawElements(gl.TRIANGLES, this._indexArray?.length as number, gl.UNSIGNED_SHORT, 0);
        }
    }

    /**
     * 当たり判定
     * @param pointX x座標
     * @param pointY y座標
     */
    public isHit(pointX: number, pointY: number): boolean {
        // 画面サイズを取得する。
        const { height } = canvas as HTMLCanvasElement;

        // Y座標は変換する必要あり
        const y = height - pointY;

        return pointX >= (this._rect?.left as number) && pointX <= (this._rect?.right as number) && y <= (this._rect?.up as number) && y >= (this._rect?.down as number);
    }
}

export class Rect {
    public left: number | null; // 左辺
    public right: number | null; // 右辺
    public up: number | null; // 上辺
    public down: number | null; // 下辺
    constructor() {
        this.left = null;
        this.right = null;
        this.up = null;
        this.down = null;
    }
}
