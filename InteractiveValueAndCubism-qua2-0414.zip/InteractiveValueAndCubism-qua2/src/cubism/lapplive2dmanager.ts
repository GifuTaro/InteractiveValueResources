/**
 * Copyright(c) Live2D Inc. All rights reserved.
 *
 * Use of this source code is governed by the Live2D Open Software license
 * that can be found at https://www.live2d.com/eula/live2d-open-software-license-agreement_en.html.
 */

import { CubismMatrix44 } from "@framework/math/cubismmatrix44";
import { ACubismMotion } from "@framework/motion/acubismmotion";
import { csmVector } from "@framework/type/csmvector";

import * as LAppDefine from "./lappdefine";
import { canvas } from "./lappdelegate";
import { LAppModel } from "./lappmodel";
import { LAppPal } from "./lapppal";

export let s_instance: LAppLive2DManager | null | undefined = null;

/**
 * サンプルアプリケーションにおいてCubismModelを管理するクラス
 * モデル生成と破棄、タップイベントの処理、モデル切り替えを行う。
 * モデルのデータ_modelsをどう動かすかを管理する
 */
export class LAppLive2DManager {
    _viewMatrix: CubismMatrix44; // モデル描画に用いるview行列
    //LAppModelはモデルそのもののデータが入っている、csmVectorはLAppModelを受け付ける格納場所
    _models: csmVector<LAppModel | null>; // モデルインスタンスのコンテナ、
    _sceneIndex: number; // 表示するシーンのインデックス値

    /**
     * クラスのインスタンス（シングルトン）を返す。
     * インスタンスが生成されていない場合は内部でインスタンスを生成する。
     *
     * @return クラスのインスタンス
     */
    public static getInstance(): LAppLive2DManager {
        if (s_instance == null) {
            s_instance = new LAppLive2DManager();
        }

        return s_instance;
    }

    /**
     * コンストラクタ
     */
    constructor() {
        this._viewMatrix = new CubismMatrix44();
        this._models = new csmVector<LAppModel>();
        this._sceneIndex = 0; //!現在のシーン、何番目のモデルを最初に使うか
        this.changeScene(this._sceneIndex);
    }

    public addEventListener(event: "start", listner: Function) {
        switch (event) {
            case "start":
                const modelCount: number = this._models.getSize();
                for (let i = 0; i < modelCount; ++i) {
                    const model: LAppModel | null = this.getModel(i);
                    model?.addEventlistener(event, listner);
                }
                break;
        }
    }

    /**
     * 画面を更新するときの処理
     * モデルの更新処理及び描画処理を行う
     * ２．「lppview」からよばれる
     */
    public onUpdate(): void {
        const { width, height } = canvas as HTMLCanvasElement;

        const modelCount: number = this._models.getSize();

        for (let i = 0; i < modelCount; ++i) {
            const projection: CubismMatrix44 = new CubismMatrix44(); //scaleメソッドで拡大率を、translateメソッドで移動できる
            const model: LAppModel | null = this.getModel(i);

            if (model?.getModel()) {
                //モデルがあるなら
                if (model.getModel().getCanvasWidth() > 1.0 && width < height) {
                    //縦画面の場合
                    // 横に長いモデルを縦長ウィンドウに表示する際モデルの横サイズでscaleを算出する
                    model.getModelMatrix().setWidth(2.0);
                    projection.scale(1.0 * LAppDefine.myScale, (width / height) * LAppDefine.myScale);
                    projection.translate(...LAppDefine.myLocation);
                } else {
                    projection.scale((height / width) * LAppDefine.myScale, 1.0 * LAppDefine.myScale);
                    projection.translate(...LAppDefine.myLocation);
                }

                // 必要があればここで乗算
                if (this._viewMatrix != null) {
                    projection.multiplyByMatrix(this._viewMatrix);
                }
            }

            model?.update(); //--------------------３.描画処理 ここでモデルの表示用のデータをを次回に向けてを更新
            model?.draw(projection); // 参照渡しなのでprojectionは変質する。
        }
    }

    /**
     * 次のシーンに切りかえる
     * サンプルアプリケーションではモデルセットの切り替えを行う。
     */
    public nextScene(): void {
        const no: number = (this._sceneIndex + 1) % LAppDefine.ModelDirSize;
        this.changeScene(no);
    }

    /**
     * シーンを切り替える
     * サンプルアプリケーションではモデルセットの切り替えを行う。
     */
    public changeScene(index: number): void {
        this._sceneIndex = index;
        if (LAppDefine.DebugLogEnable) {
            LAppPal.printMessage(`[APP]model index: ${this._sceneIndex}`);
        }

        // ModelDir[]に保持したディレクトリ名から
        // model3.jsonのパスを決定する。
        // ディレクトリ名とmodel3.jsonの名前を一致させておくこと。
        const model: string = LAppDefine.ModelDir[index]; //文字列でどのモデル化取得する
        const modelPath: string = LAppDefine.ResourcesPath + model + "/"; //ここでモデルの位置を定義
        let modelJsonName: string = LAppDefine.ModelDir[index];
        modelJsonName += ".model3.json";

        this.releaseAllModel();
        this._models.pushBack(new LAppModel()); //Lappモデルはモデル本体キャッシュにモデルを格納
        this._models.at(0)?.loadAssets(modelPath, modelJsonName); //model3.jsonが置かれたディレクトリとファイルパスからモデルを生成する
    }

    public setViewMatrix(m: CubismMatrix44) {
        for (let i = 0; i < 16; i++) {
            this._viewMatrix.getArray()[i] = m.getArray()[i];
        }
    }

    // モーション再生終了のコールバック関数
    _finishedMotion = (self: ACubismMotion): void => {
        LAppPal.printMessage("Motion Finished:");
        console.log(self);
    };

    /**
     * クラスのインスタンス（シングルトン）を解放する。
     */
    public static releaseInstance(): void {
        if (s_instance != null) {
            s_instance = void 0;
        }

        s_instance = null;
    }

    /**
     * 現在のシーンで保持しているモデルを返す。
     *
     * @param no モデルリストのインデックス値
     * @return モデルのインスタンスを返す。インデックス値が範囲外の場合はNULLを返す。
     */
    public getModel(no: number): LAppModel | null {
        if (no < this._models.getSize()) {
            return this._models.at(no);
        }

        return null;
    }

    /**
     * 現在のシーンで保持しているすべてのモデルを解放する
     */
    public releaseAllModel(): void {
        for (let i = 0; i < this._models.getSize(); i++) {
            this._models.at(i)?.release();
            this._models.set(i, null);
        }

        this._models.clear();
    }

    /**
     * 画面をドラッグした時の処理
     *
     * @param x 画面のX座標
     * @param y 画面のY座標
     */
    public onDrag(x: number, y: number): void {
        for (let i = 0; i < this._models.getSize(); i++) {
            const model: LAppModel | null = this.getModel(i);

            if (model) {
                /**
                 * マウスドラッグ情報の設定
                 * @param ドラッグしているカーソルのX位置
                 * @param ドラッグしているカーソルのY位置
                 */
                model.setDragging(x, y); //論理変換マウス座標をモデルに登録
                /**
                 * ↓
                 * this.dragManager
                 * =cubismtargetpointクラスのインスタンス
                 * ＝顔の向きの制御機能を提供するクラス
                 * に論理変換マウス座標を伝える。
                 */
            }
        }
    }

    /**
     * 画面をタップした時の処理
     *
     * @param x 画面のX座標
     * @param y 画面のY座標
     */
    public onTap(x: number, y: number): void {
        if (LAppDefine.DebugLogEnable) {
            /*---------------------------------------クリック場所出力無力化
      LAppPal.printMessage(
        `[APP]tap point: {x: ${x.toFixed(2)} y: ${y.toFixed(2)}}`
      );
      */
        }

        for (let i = 0; i < this._models.getSize(); i++) {
            if (this._models.at(i)?.hitTest(LAppDefine.HitAreaNameHead, x, y)) {
                //-----------------------頭を触り終わったら
                if (LAppDefine.DebugLogEnable) {
                    LAppPal.printMessage(`[APP]hit area: [${LAppDefine.HitAreaNameHead}]`);
                }
                this._models.at(i)?.setRandomExpression(); //---------------------------------ランダムな表情を取る
            } else if (this._models.at(i)?.hitTest(LAppDefine.HitAreaNameBody, x, y)) {
                //------------------------------体を触ったら
                if (LAppDefine.DebugLogEnable) {
                    LAppPal.printMessage(`[APP]hit area: [${LAppDefine.HitAreaNameBody}]`);
                }

                //--------------------------------------------ランダムなモーションをとる
                this._models.at(i)?.startRandomMotion(LAppDefine.MotionGroupTapBody, LAppDefine.PriorityForce, this._finishedMotion);
            }
        }
    }

    /**
     * モデルの口パクフラグをオンするメソッド
     */
    public speakStart(): void {
        const modelCount: number = this._models.getSize();
        for (let i = 0; i < modelCount; ++i) {
            const model: LAppModel | null = this.getModel(i);
            if (model?.getModel()) {
                //モデルがあるなら
                model.speakOn();
            }
        }
    }
    /**
     * モデルの口パクフラグをオンするメソッド
     */
    public speakStop(): void {
        const modelCount: number = this._models.getSize();
        for (let i = 0; i < modelCount; ++i) {
            const model: LAppModel | null = this.getModel(i);
            if (model?.getModel()) {
                //モデルがあるなら
                model.speakOff();
            }
        }
    }

    public isSpeakings(): boolean[] {
        const modelCount: number = this._models.getSize();
        let status: boolean[] = [];
        for (let i = 0; i < modelCount; ++i) {
            const model: LAppModel | null = this.getModel(i);
            if (model?.getModel()) {
                //モデルがあるなら
                status.push(model.isSpeaking());
            }
        }

        return status;
    }
}
